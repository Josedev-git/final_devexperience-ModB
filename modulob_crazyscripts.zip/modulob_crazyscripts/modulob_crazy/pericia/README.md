# Parte 2 — Perícia de rede: pendente da captura

O arquivo **captura_biofrio_2026.pcap** não foi fornecido. Não é possível afirmar IP do cliente, senhas, cookie, comando suspeito, horários reais ou classificação do incidente sem examinar os pacotes.

Quando a captura estiver disponível, produzir o PDF exigido, acompanhado de capturas de tela do Wireshark (pacote selecionado + detalhes), respondendo às quatro questões do enunciado.

Roteiro de investigação:

1. Ajustar a exibição para data e hora, UTC−3. Identificar publicações em tópico terminado em `/telemetria`, origem/destino, versão de IP, porta, `placa` e tópico completo.
2. Inspecionar POST de login e resposta HTTP, campos de formulário, URL encoding e Set-Cookie. `%40` representa `@`; isso não revela, por si só, qual senha foi usada. Verificar MQTT CONNECT para credenciais do dispositivo.
3. Filtrar publicações em `biofrio/cam03/cmd`, especialmente próximo de 14:14:30. Comparar origem com o servidor autorizado 192.168.20.10, conferir SUBSCRIBE e entrega do broker ao dispositivo.
4. Ordenar telemetria antes/depois do comando e documentar temperaturas, estados e mudanças. Classificar o incidente somente a partir dessas evidências.
5. Recomendar TLS validado em HTTP/MQTT, autenticação individual e ACL por tópico no broker, e autenticação/integridade dos comandos com proteção contra replay.

Filtros úteis (o nome exato dos campos MQTT pode variar com a versão do Wireshark):

```text
http.request.method == "POST"
mqtt
mqtt.msgtype == 1
mqtt.msgtype == 3
mqtt.msgtype == 8
ip.addr == 192.168.20.10
```

Este roteiro não substitui as respostas nem as evidências que o PDF solicita.
