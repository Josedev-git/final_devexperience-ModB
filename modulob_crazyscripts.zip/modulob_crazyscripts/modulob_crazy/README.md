# VaxGuard Connect — SENAI Dev Experience, módulo B

Projeto com firmware **C++/Arduino** e servidor **Python/Flask + SQLite**.

Abra **vaxguard_nomeEquipe/README.md** para instalação, ligações, protocolo e testes.

No Windows: entre em **vaxguard_nomeEquipe** e execute **INICIAR_WINDOWS.bat**. Ele cria o ambiente Python, instala as dependências, gera as credenciais e inicia o painel em http://localhost:5000. A placa é carregada separadamente pela Arduino IDE.

Troque `nomeEquipe` pelo nome da sua equipe antes da entrega formal. A organização pedida é preservada: `modulob_nomeEquipe/vaxguard_nomeEquipe`.

A Parte 1 foi implementada neste pacote; compilação e testes documentados em `vaxguard_nomeEquipe/VALIDACAO.md`. O ensaio físico e a integração na rede dos avaliadores ainda precisam ser realizados.

A Parte 2 está pendente da captura original `.pcap`; veja `pericia/README.md`. O repositório remoto, as permissões para os avaliadores e os oito commits distribuídos ao longo da prova devem ser feitos pela equipe; não foram fabricados nesta entrega.
