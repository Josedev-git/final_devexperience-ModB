#pragma once
#include <Arduino.h>
#include <DHT.h>
#include "core.h"
#include "secrets.h"

#if defined(ARDUINO_UNOR4_WIFI)
 #include <WiFiS3.h>
 #include <WiFiUdp.h>
 #include <EEPROM.h>
 #include <WDT.h>
 #include <Arduino_LED_Matrix.h>
 constexpr char BOARD_NAME[]="UNO R4 WiFi";
 constexpr uint8_t PIN_DHT=2,PIN_DOOR=3,PIN_BUTTON=4,PIN_VIBRATION=7,PIN_LIGHT=A0;
 constexpr uint8_t PIN_RED=9,PIN_GREEN=10,PIN_BLUE=11,PIN_BUZZER=5,PIN_RELAY=6;
 constexpr unsigned ADC_MAXIMUM=16383;
 ArduinoLEDMatrix matrix;
 struct HalGuard { HalGuard(){} ~HalGuard(){} }; // UNO: tarefas cooperativas, sem acesso concorrente
#elif defined(ESP32)
 #include <WiFi.h>
 #include <WiFiUdp.h>
 #include <Preferences.h>
 #include <esp_task_wdt.h>
 #include <esp_arduino_version.h>
 constexpr char BOARD_NAME[]="ESP32";
 constexpr uint8_t PIN_DHT=4,PIN_DOOR=27,PIN_BUTTON=26,PIN_VIBRATION=33,PIN_LIGHT=34;
 constexpr uint8_t PIN_RED=18,PIN_GREEN=19,PIN_BLUE=21,PIN_BUZZER=23,PIN_RELAY=22;
 constexpr unsigned ADC_MAXIMUM=4095;
 Preferences preferences;
 portMUX_TYPE halMux=portMUX_INITIALIZER_UNLOCKED;
 struct HalGuard { HalGuard(){portENTER_CRITICAL(&halMux);} ~HalGuard(){portEXIT_CRITICAL(&halMux);} };
#else
 #error "Placa nao suportada: use UNO R4 WiFi ou ESP32"
#endif

constexpr bool RELAY_ACTIVE_LOW=true, RGB_COMMON_ANODE=false;
DHT halDht(PIN_DHT,DHT11);
struct Stored { uint32_t magic=0x56475832,generation=0;Config config;uint64_t seqHi=0;uint32_t lastCommand=0,crc=0; };
Stored halStored;
uint64_t halSeq=0;
uint32_t halLastMs=0;
uint64_t halUptime=0,halSyncUptime=0;
uint32_t halUnix=0;
volatile bool halVibration=false;

inline uint32_t hal_crc(const Stored& s){const uint8_t* p=(const uint8_t*)&s;uint32_t c=2166136261UL;for(size_t i=0;i<offsetof(Stored,crc);++i)c=(c^p[i])*16777619UL;return c;}
inline bool hal_validStore(const Stored& s){return s.magic==0x56475832&&validConfig(s.config)&&s.crc==hal_crc(s);}
inline bool hal_commit(Stored next){
 next.generation=halStored.generation+1;next.crc=hal_crc(next);
#if defined(ARDUINO_UNOR4_WIFI)
 EEPROM.put((next.generation%2)*sizeof(Stored),next);
 Stored verify;EEPROM.get((next.generation%2)*sizeof(Stored),verify);
 if(!hal_validStore(verify))return false;
#elif defined(ESP32)
 const char* key=next.generation%2?"slot1":"slot0";
 if(preferences.putBytes(key,&next,sizeof(next))!=sizeof(next))return false;
#endif
 halStored=next;return true;
}
inline bool hal_saveConfig(const Config& config){if(!validConfig(config))return false;Stored next=halStored;next.config=config;return hal_commit(next);}
inline bool hal_saveCommand(uint32_t id){Stored next=halStored;next.lastCommand=id;return hal_commit(next);}
inline void hal_reset();
inline uint64_t hal_nextSeq(){
 if(halSeq>=halStored.seqHi){Stored next=halStored;next.seqHi=halSeq+512;if(!hal_commit(next)){Serial.println("NVS/EEPROM indisponivel: reiniciando");hal_reset();return 0; }}
 return ++halSeq;
}
inline uint64_t hal_uptime(){uint32_t now=millis();HalGuard guard;halUptime+=(uint32_t)(now-halLastMs);halLastMs=now;return halUptime;}
inline uint32_t hal_timestamp(uint64_t now){HalGuard guard;if(!halUnix)return 0;int64_t value=(int64_t)halUnix+((int64_t)now-(int64_t)halSyncUptime)/1000;return value>0?(uint32_t)value:0;}
inline void hal_vibrationIRQ(){halVibration=true;}
inline Inputs hal_inputs(uint32_t now){
 static bool lastButton=false,stableButton=false,lastDoor=false,stableDoor=false;
 static uint32_t buttonAt=0,doorAt=0;
 bool button=digitalRead(PIN_BUTTON)==LOW,door=digitalRead(PIN_DOOR)==HIGH;
 if(button!=lastButton){lastButton=button;buttonAt=now;}
 if(door!=lastDoor){lastDoor=door;doorAt=now;}
 Inputs in;
 if((uint32_t)(now-buttonAt)>=50&&stableButton!=button){in.button=button;stableButton=button;}
 if((uint32_t)(now-doorAt)>=50)stableDoor=door;
 in.door=stableDoor;
 noInterrupts();in.vibration=halVibration;halVibration=false;interrupts();
 in.vibration=in.vibration||digitalRead(PIN_VIBRATION)==LOW;
 in.light=constrain(analogRead(PIN_LIGHT)*100.0f/ADC_MAXIMUM,0.0f,100.0f);
 return in;
}
inline void hal_readDht(float& t,float& h){h=halDht.readHumidity();t=halDht.readTemperature();}
inline void hal_rgb(uint8_t red,uint8_t green,uint8_t blue){
 if(RGB_COMMON_ANODE){red=255-red;green=255-green;blue=255-blue;}
#if defined(ARDUINO_UNOR4_WIFI)
 analogWrite(PIN_RED,red);analogWrite(PIN_GREEN,green);analogWrite(PIN_BLUE,blue);
#elif defined(ESP32)
 #if ESP_ARDUINO_VERSION_MAJOR >= 3
 ledcWrite(PIN_RED,red);ledcWrite(PIN_GREEN,green);ledcWrite(PIN_BLUE,blue);
 #else
 ledcWrite(0,red);ledcWrite(1,green);ledcWrite(2,blue);
 #endif
#endif
}
inline void hal_outputs(State state,bool vent,uint64_t elapsed){
 bool phase=elapsed%1000<500;
 if(state==NORMAL)hal_rgb(0,255,0);
 else if(state==ATENCAO)hal_rgb(255,180,0);
 else if(state==CRITICO)hal_rgb(255,0,0);
 else if(state==RECONHECIDO)hal_rgb(phase?255:0,0,0);
 else hal_rgb(255,phase?180:0,0);
 bool sound=state==CRITICO||(state==ATENCAO&&elapsed%10000<150);
 // Buzzer ATIVO do kit: nivel digital continuo; para passivo substituir por tone.
 digitalWrite(PIN_BUZZER,sound?HIGH:LOW);
 digitalWrite(PIN_RELAY,(vent^RELAY_ACTIVE_LOW)?HIGH:LOW);
#if defined(ARDUINO_UNOR4_WIFI)
 static int last=-1;int key=(int)state*2+((state==RECONHECIDO||state==FALHA_SENSOR)?phase:0);
 if(key!=last){
  last=key;uint8_t pixels[8][12]={0};
  const uint8_t glyphs[5][7]={{17,25,25,21,19,19,17},{14,17,17,31,17,17,17},{14,17,16,16,16,17,14},{30,17,17,30,20,18,17},{31,16,16,30,16,16,16}};
  if(state!=RECONHECIDO||phase)for(int y=0;y<7;y++)for(int x=0;x<5;x++)pixels[y][x+3]=(glyphs[state][y]>>(4-x))&1;
  matrix.renderBitmap(pixels,8,12);
 }
#endif
}
inline void hal_feed(){
#if defined(ARDUINO_UNOR4_WIFI)
 WDT.refresh();
#elif defined(ESP32)
 esp_task_wdt_reset();
#endif
}
inline void hal_reset(){
#if defined(ARDUINO_UNOR4_WIFI)
 NVIC_SystemReset();
#elif defined(ESP32)
 ESP.restart();
#endif
}
inline void hal_begin(){
 pinMode(PIN_RELAY,OUTPUT);digitalWrite(PIN_RELAY,RELAY_ACTIVE_LOW?HIGH:LOW);
 pinMode(PIN_BUZZER,OUTPUT);digitalWrite(PIN_BUZZER,LOW);
 pinMode(PIN_DOOR,INPUT_PULLUP);pinMode(PIN_BUTTON,INPUT_PULLUP);pinMode(PIN_VIBRATION,INPUT_PULLUP);
 pinMode(PIN_LIGHT,INPUT);pinMode(PIN_RED,OUTPUT);pinMode(PIN_GREEN,OUTPUT);pinMode(PIN_BLUE,OUTPUT);
 attachInterrupt(digitalPinToInterrupt(PIN_VIBRATION),hal_vibrationIRQ,FALLING);
 halDht.begin();
 Stored a={},b={};a.magic=b.magic=0;
#if defined(ARDUINO_UNOR4_WIFI)
 analogReadResolution(14);analogWriteResolution(8);matrix.begin();
 EEPROM.get(0,a);EEPROM.get(sizeof(Stored),b);
 WDT.begin(8000);WiFi.setTimeout(100);
#elif defined(ESP32)
 analogReadResolution(12);analogSetPinAttenuation(PIN_LIGHT,ADC_11db);
 preferences.begin("vaxguard",false);preferences.getBytes("slot0",&a,sizeof(a));preferences.getBytes("slot1",&b,sizeof(b));
 #if ESP_ARDUINO_VERSION_MAJOR >= 3
 ledcAttach(PIN_RED,1000,8);ledcAttach(PIN_GREEN,1000,8);ledcAttach(PIN_BLUE,1000,8);
 esp_task_wdt_config_t wdt={};wdt.timeout_ms=8000;wdt.idle_core_mask=0;wdt.trigger_panic=true;
 if(esp_task_wdt_init(&wdt)==ESP_ERR_INVALID_STATE)esp_task_wdt_reconfigure(&wdt);
 #else
 ledcSetup(0,1000,8);ledcSetup(1,1000,8);ledcSetup(2,1000,8);ledcAttachPin(PIN_RED,0);ledcAttachPin(PIN_GREEN,1);ledcAttachPin(PIN_BLUE,2);
 esp_task_wdt_init(8,true);
 #endif
 esp_task_wdt_add(nullptr);WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(false);
#endif
 if(hal_validStore(a))halStored=a;
 if(hal_validStore(b)&&(!hal_validStore(a)||(int32_t)(b.generation-a.generation)>0))halStored=b;
 halSeq=halStored.seqHi;halLastMs=millis();hal_outputs(ATENCAO,false,0);
}

// Rede: nenhuma chamada dependente de placa sai deste arquivo.
WiFiClient halClient;
WiFiUDP halUdp;
IPAddress halServer,halNtp;
uint16_t halPort=5000;
inline bool hal_networkConfig(){
 String url=SERVER_URL;if(!url.startsWith("http://"))return false;url.remove(0,7);
 int colon=url.indexOf(':');String ip=colon<0?url:url.substring(0,colon);
 if(colon>=0)halPort=(uint16_t)url.substring(colon+1).toInt();else halPort=80;
 if(!halPort||!halServer.fromString(ip)||!halNtp.fromString(NTP_IP))return false;
#if defined(ARDUINO_UNOR4_WIFI)
 halClient.setConnectionTimeout(100);
#endif
 return true;
}
inline bool hal_wifiStep(){
 static bool waiting=false;static uint32_t attemptAt=0,retryAt=0,backoff=1000;
 uint32_t now=millis();
 if(WiFi.status()==WL_CONNECTED){waiting=false;backoff=1000;return true;}
 if(waiting){if((uint32_t)(now-attemptAt)<8000)return false;WiFi.disconnect();waiting=false;retryAt=now+backoff;backoff=backoff>=15000?30000:backoff*2;}
 if((int32_t)(now-retryAt)>=0&&!waiting){WiFi.begin(WIFI_SSID,WIFI_PASSWORD);attemptAt=millis();waiting=true;}
 return false;
}
inline bool hal_connect(){
#if defined(ARDUINO_UNOR4_WIFI)
 return halClient.connect(halServer,halPort)==1;
#elif defined(ESP32)
 return halClient.connect(halServer,halPort,200)==1;
#endif
}
struct HttpState { bool active=false;uint32_t start=0;String request,response;size_t sent=0;int status=0; }halHttp;
inline bool hal_httpStart(const char* method,const char* path,const String& body){
 if(halHttp.active)return false;
 halClient.stop();if(!hal_connect())return false;
 halHttp=HttpState();halHttp.active=true;halHttp.start=millis();
 halHttp.request=String(method)+" "+path+" HTTP/1.0\r\nHost: "+halServer.toString()+":"+String(halPort)+"\r\nAuthorization: Bearer "+API_TOKEN+"\r\nContent-Type: application/json\r\nContent-Length: "+String(body.length())+"\r\nConnection: close\r\n\r\n"+body;
 halHttp.response.reserve(1800);return true;
}
// 0: pendente, 1: sucesso, -1: falha. A cada chamada processa no maximo 256 bytes.
inline int hal_httpStep(String& body){
 if(!halHttp.active)return -1;
 if((uint32_t)(millis()-halHttp.start)>4000){halClient.stop();halHttp.active=false;return -1;}
 if(halHttp.sent<halHttp.request.length()){
  size_t left=halHttp.request.length()-halHttp.sent;size_t amount=left>128?128:left;
  halHttp.sent+=halClient.write((const uint8_t*)halHttp.request.c_str()+halHttp.sent,amount);return 0;
 }
 for(unsigned i=0;i<256&&halClient.available();++i){halHttp.response+=(char)halClient.read();if(halHttp.response.length()>2048){halClient.stop();halHttp.active=false;return -1;}}
 int split=halHttp.response.indexOf("\r\n\r\n");
 bool complete=!halClient.connected()&&!halClient.available();
 int length=-1;
 if(split>=0){String header=halHttp.response.substring(0,split);header.toLowerCase();int p=header.indexOf("content-length:");if(p>=0)length=header.substring(p+15).toInt();if(header.indexOf("transfer-encoding:")>=0){halClient.stop();halHttp.active=false;return -1;}if(length>=0&&(int)halHttp.response.length()-split-4>=length)complete=true;}
 if(!complete)return 0;
 halClient.stop();halHttp.active=false;
 if(split<0)return -1;
 int status=halHttp.response.substring(9,12).toInt();body=halHttp.response.substring(split+4);
 if(length>=0&&(int)body.length()!=length)return -1;
 return status>=200&&status<300?1:-1;
}
inline void hal_ntpStep(){
 static bool initialized=false,waiting=false;static uint32_t next=0,sent=0;static uint8_t cookie[8];
 uint32_t now=millis();if((int32_t)(now-next)<0&&!waiting)return;
 if(!initialized){halUdp.begin(2390);initialized=true;}
 if(!waiting){uint8_t packet[48]={0};packet[0]=0x23;for(int i=0;i<8;++i)cookie[i]=packet[40+i]=(uint8_t)random(1,255);halUdp.beginPacket(halNtp,123);halUdp.write(packet,48);halUdp.endPacket();waiting=true;sent=now;return;}
 if(halUdp.parsePacket()>=48){uint8_t reply[48];halUdp.read(reply,48);
  if(halUdp.remoteIP()==halNtp&&halUdp.remotePort()==123&&(reply[0]&7)==4&&(reply[0]>>6)!=3&&reply[1]>0&&reply[1]<=15&&!memcmp(reply+24,cookie,8)){
   uint32_t seconds=((uint32_t)reply[40]<<24)|((uint32_t)reply[41]<<16)|((uint32_t)reply[42]<<8)|reply[43];
   if(seconds>2208988800UL){uint32_t unixTime=seconds-2208988800UL;if(unixTime>=1704067200UL){HalGuard guard;halUnix=unixTime;halSyncUptime=halUptime;waiting=false;next=now+3600000;}}
  }
 }
 if(waiting&&(uint32_t)(now-sent)>2500){waiting=false;next=now+30000;}
}
static void (*halNetworkFunction)()=nullptr;
#if defined(ESP32)
inline void hal_networkWorker(void*){while(true){halNetworkFunction();vTaskDelay(pdMS_TO_TICKS(2));}}
#endif
inline bool hal_startNetwork(void(*callback)()){
 if(!hal_networkConfig())return false;halNetworkFunction=callback;
#if defined(ESP32)
 return xTaskCreate(hal_networkWorker,"vaxguard-net",6144,nullptr,1,nullptr)==pdPASS;
#else
 return true;
#endif
}
inline void hal_pollNetwork(){
#if defined(ARDUINO_UNOR4_WIFI)
 if(halNetworkFunction)halNetworkFunction();
#endif
}
