#include <ArduinoJson.h>
#include "board.h"
// Nenhuma diretiva de placa ou GPIO na logica da aplicacao.
Config config;
Machine machine;
Ring<Packet,32> readings;
Ring<Packet,16> events;
Command mailbox;
bool commandReady=false,manualVentilation=false;
volatile uint32_t lastCommand=0;
uint64_t stateSince=0,lastSample=0,rebootAt=0;
bool firstSample=true;

void eventPacket(const char* type,const char* reason,State before,State after,uint64_t now,uint32_t cid=0){
 Packet p;p.seq=hal_nextSeq();p.uptime=now;p.ts=hal_timestamp(now);p.event=true;p.before=before;p.state=after;p.command=cid;
 snprintf(p.type,sizeof(p.type),"%s",type);snprintf(p.reason,sizeof(p.reason),"%s",reason);
 HalGuard guard;events.push(p);
}
String serializePacket(const Packet& p){
 JsonDocument doc;doc["device_id"]=DEVICE_ID;doc["placa"]=BOARD_NAME;doc["seq"]=p.seq;
 // Congela a representacao no momento da coleta. Retry nunca altera o payload.
 if(p.ts)doc["ts"]=p.ts;else doc["ts"]=nullptr;
 doc["uptime_ms"]=p.uptime;
 if(p.event){doc["tipo"]=p.type;doc["motivo"]=p.reason;doc["anterior"]=stateName(p.before);doc["novo"]=stateName(p.state);if(p.command)doc["command_id"]=p.command;}
 else {
  if(isfinite(p.temp)&&isfinite(p.humidity)){doc["temp"]=p.temp;doc["umid"]=p.humidity;}else{doc["temp"]=nullptr;doc["umid"]=nullptr;}
  doc["porta"]=p.door?1:0;doc["estado"]=stateName(p.state);doc["luz_pct"]=p.light;doc["vibracao"]=p.vibration?1:0;
  doc["perdidas_leituras"]=p.lost;doc["temp_min"]=p.low;doc["temp_max"]=p.high;doc["intervalo_ms"]=p.interval;
 }
 String out;serializeJson(doc,out);return out;
}
void decodeCommand(const String& body){
 JsonDocument doc;if(deserializeJson(doc,body))return;
 JsonArray array=doc["comandos"].as<JsonArray>();if(array.size()!=1)return;
 JsonObject input=array[0];if(!input["id"].is<uint32_t>())return;
 Command cmd;cmd.id=input["id"].as<uint32_t>();if(!cmd.id||cmd.id>=2147483647||cmd.id<=lastCommand)return;
 const char* op=input["comando"]|"";
 JsonObject params=input["parametros"].as<JsonObject>();
 if(!strcmp(op,"SET_LIMITES")&&params.size()==2&&params["temp_min"].is<float>()&&params["temp_max"].is<float>()){
  cmd.op=OP_LIMITS;cmd.low=params["temp_min"];cmd.high=params["temp_max"];
 }else if(!strcmp(op,"SET_INTERVALO")&&params.size()==1&&params["intervalo_ms"].is<uint32_t>()){
  cmd.op=OP_INTERVAL;cmd.interval=params["intervalo_ms"];
 }else if(!strcmp(op,"VENTILACAO_ON"))cmd.op=OP_ON;
 else if(!strcmp(op,"VENTILACAO_OFF"))cmd.op=OP_OFF;
 else if(!strcmp(op,"REINICIAR"))cmd.op=OP_RESET;
 HalGuard guard;if(!commandReady){mailbox=cmd;commandReady=true;}
}
void networkTick(){
 static bool active=false,isGet=false,sendingEvent=false;
 static uint64_t sendingSeq=0;
 static uint32_t pollAt=0,retryAt=0,backoff=1000;
 uint32_t now=millis();if(!hal_wifiStep())return;hal_ntpStep();
 if(active){
  String body;int result=hal_httpStep(body);if(!result)return;
  active=false;
  if(result<0){retryAt=now+backoff;backoff=backoff>=15000?30000:backoff*2;return;}
  backoff=1000;
  if(isGet)decodeCommand(body);
  else {HalGuard guard;if(sendingEvent)events.confirm(sendingSeq);else readings.confirm(sendingSeq);}
  return;
 }
 if((int32_t)(now-retryAt)<0)return;
 bool occupied;{HalGuard guard;occupied=commandReady;}
 if((int32_t)(now-pollAt)>=0&&!occupied){
  char path[128];snprintf(path,sizeof(path),"/api/dispositivos/%s/comandos?apos=%lu",DEVICE_ID,(unsigned long)lastCommand);
  pollAt=now+5000;isGet=true;active=hal_httpStart("GET",path,"");
 }else{
  Packet a,b,out;bool haveA,haveB;
  {HalGuard guard;haveA=readings.peek(a);haveB=events.peek(b);}
  if(!haveA&&!haveB)return;
  sendingEvent=haveB&&(!haveA||b.seq<a.seq);out=sendingEvent?b:a;sendingSeq=out.seq;isGet=false;
  active=hal_httpStart("POST",sendingEvent?"/api/eventos":"/api/telemetria",serializePacket(out));
 }
 if(!active){retryAt=now+backoff;backoff=backoff>=15000?30000:backoff*2;}
}
void processCommand(uint64_t now){
 Command cmd;{HalGuard guard;if(!commandReady)return;cmd=mailbox;commandReady=false;}
 if(cmd.id<=lastCommand)return;
 bool ok=true;Config candidate=config;
 if(cmd.op==OP_LIMITS){candidate.low=cmd.low;candidate.high=cmd.high;ok=validConfig(candidate)&&hal_saveConfig(candidate);if(ok){config=candidate;machine.outActive=false;if(machine.failures==0&&isfinite(machine.temp))machine.sample(machine.temp,machine.humidity,now,config);}}
 else if(cmd.op==OP_INTERVAL){candidate.interval=cmd.interval;ok=validConfig(candidate)&&hal_saveConfig(candidate);if(ok)config=candidate;}
 else if(cmd.op==OP_ON)manualVentilation=true;
 else if(cmd.op==OP_OFF)manualVentilation=false;
 else if(cmd.op!=OP_RESET)ok=false;
 // Cursor persistente tambem para rejeicoes: nao bloquear comandos seguintes.
 if(!hal_saveCommand(cmd.id)){eventPacket("COMANDO_REJEITADO","Falha de persistencia do cursor",machine.state,machine.state,now,cmd.id);return;}
 lastCommand=cmd.id;
 eventPacket(ok?"COMANDO_EXECUTADO":"COMANDO_REJEITADO",ok?"Comando aplicado":"Parametros invalidos",machine.state,machine.state,now,cmd.id);
 if(ok&&cmd.op==OP_RESET)rebootAt=now+5000;
}
void localTick(){
 uint64_t now=hal_uptime();processCommand(now);Inputs input=hal_inputs(millis());
 bool collect=firstSample||now-lastSample>=config.interval;float temp=NAN,humidity=NAN;bool valid=false;
 if(collect){hal_readDht(temp,humidity);now=hal_uptime();valid=machine.sample(temp,humidity,now,config);lastSample=now;firstSample=false;if(Serial){Serial.print("DHT temp=");Serial.print(temp);Serial.print(" umid=");Serial.println(humidity);}}
 State before=machine.state;State after=machine.step(now,input,config);
 if(after!=before){if(Serial){Serial.print("ESTADO: ");Serial.println(stateName(after));}stateSince=now;const char* reason=after==FALHA_SENSOR?"3 leituras invalidas consecutivas":after==CRITICO?"Temperatura fora >30 s ou porta aberta >60 s":after==RECONHECIDO?"Reconhecimento pelo botao local":after==NORMAL?"Condicoes normalizadas":"Margem termica, porta >20 s ou sensores extras";eventPacket(after==FALHA_SENSOR?"SENSOR_FALHA":"MUDANCA_ESTADO",reason,before,after,now);}
 hal_outputs(after,machine.ventilate(manualVentilation),now-stateSince);
 if(collect){Packet p;p.seq=hal_nextSeq();p.uptime=now;p.ts=hal_timestamp(now);p.temp=valid?temp:NAN;p.humidity=valid?humidity:NAN;p.door=input.door;p.vibration=input.vibration;p.light=input.light;p.state=after;p.low=config.low;p.high=config.high;p.interval=config.interval;{HalGuard guard;p.lost=readings.dropped;readings.push(p);}}
 hal_feed();if(rebootAt&&now>=rebootAt)hal_reset();
}
void setup(){Serial.begin(115200);hal_begin();config=halStored.config;lastCommand=halStored.lastCommand;eventPacket("BOOT","Inicializacao do dispositivo",NORMAL,NORMAL,hal_uptime());if(!hal_startNetwork(networkTick))Serial.println("Configuracao da rede invalida; alarmes locais continuam ativos");}
void loop(){localTick();hal_pollNetwork();yield();}
