#pragma once
// Copie para secrets.h; nunca publique o arquivo real.
constexpr char WIFI_SSID[]="REDE_DOS_AVALIADORES";
constexpr char WIFI_PASSWORD[]="ALTERE_AQUI";
constexpr char DEVICE_ID[]="VG-CAM01";
constexpr char API_TOKEN[]="TOKEN_DEVICE_TOKEN_DO_ENV_GERADO_PELO_SERVIDOR";
// IPv4 literal: evita DNS bloqueante. Origem sem barra final nem caminho.
constexpr char SERVER_URL[]="http://192.168.20.10:5000";
constexpr char NTP_IP[]="192.168.20.10"; // deve oferecer UDP 123; pode ser outro servidor NTP
