#pragma once
#include <stdint.h>
#include <math.h>
#include <stddef.h>

struct Config { float low=2, high=8, lightLimit=80; uint32_t interval=5000; };
inline bool validConfig(const Config& c) { return isfinite(c.low)&&isfinite(c.high)&&isfinite(c.lightLimit)&&c.low>=-40&&c.high<=80&&c.high-c.low>2&&c.interval>=2000&&c.interval<=60000&&c.lightLimit>=0&&c.lightLimit<=100; }
enum State : uint8_t { NORMAL, ATENCAO, CRITICO, RECONHECIDO, FALHA_SENSOR };
inline const char* stateName(State s) { const char* names[]={"NORMAL","ATENCAO","CRITICO","RECONHECIDO","FALHA_SENSOR"}; return names[(unsigned)s<5?s:NORMAL]; }
struct Inputs { bool door=false,button=false,vibration=false; float light=0; };
struct Machine {
 State state=NORMAL; unsigned failures=0; float temp=NAN,humidity=NAN;
 bool doorActive=false,outActive=false,ack=false,hazard=false;
 uint64_t doorAt=0,outAt=0,vibrationUntil=0;
 bool sample(float t,float h,uint64_t now,const Config& c) {
  if(!isfinite(t)||!isfinite(h)||t < -40||t>80||h<0||h>100) { if(failures<1000000)++failures; outActive=false; return false; }
  failures=0;temp=t;humidity=h;
  bool outside=t<c.low||t>c.high;
  if(outside&&!outActive){outAt=now;outActive=true;} else if(!outside)outActive=false;
  return true;
 }
 State step(uint64_t now,const Inputs& in,const Config& c) {
  if(in.door&&!doorActive){doorAt=now;doorActive=true;}else if(!in.door)doorActive=false;
  if(in.vibration)vibrationUntil=now+10000;
  bool extra=in.light>=c.lightLimit||now<vibrationUntil;
  bool known=failures==0&&isfinite(temp);
  bool safe=known&&temp>=c.low&&temp<=c.high&&!in.door&&!extra;
  if(safe)ack=false;
  if(in.button&&state==CRITICO)ack=true;
  hazard=(doorActive&&now-doorAt>60000)||(outActive&&now-outAt>30000);
  if(failures>=3)state=FALHA_SENSOR;
  else if(ack)state=RECONHECIDO;
  else if(hazard)state=CRITICO;
  else if(!known||extra||(known&&(temp<c.low+1||temp>c.high-1))||(doorActive&&now-doorAt>20000))state=ATENCAO;
  else state=NORMAL;
  return state;
 }
 bool ventilate(bool manual)const { return manual||hazard||state==CRITICO||state==RECONHECIDO||state==FALHA_SENSOR; }
};
struct Packet {
 uint64_t seq=0,uptime=0; uint32_t ts=0,command=0;
 float temp=NAN,humidity=NAN,light=0,low=2,high=8; uint32_t interval=5000,lost=0;
 State before=NORMAL,state=NORMAL; bool event=false,door=false,vibration=false;
 char type[28]={0},reason[112]={0};
};
template<class T,size_t N>struct Ring {
 T data[N]; size_t head=0,count=0; uint32_t dropped=0;
 void push(const T& item){if(count==N){head=(head+1)%N;--count;++dropped;}data[(head+count)%N]=item;++count;}
 bool peek(T& out)const{if(!count)return false;out=data[head];return true;}
 void confirm(uint64_t seq){if(count&&data[head].seq==seq){head=(head+1)%N;--count;}}
};
enum Op : uint8_t { OP_INVALID, OP_LIMITS, OP_INTERVAL, OP_ON, OP_OFF, OP_RESET };
struct Command { uint32_t id=0; Op op=OP_INVALID; float low=NAN,high=NAN; uint32_t interval=0; };
