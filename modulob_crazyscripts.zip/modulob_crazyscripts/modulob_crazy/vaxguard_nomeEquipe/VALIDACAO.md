# Validação executada

## Firmware C++ — compilação real

Compilado com Arduino CLI 1.5.2-rc.1, usando cópia temporária do sketch com as credenciais fictícias de `secrets.example.h`. Nenhum segredo real foi necessário. O fonte entregue é o mesmo da compilação.

| Alvo | Core | Resultado | Flash | Globais RAM |
|---|---|---|---:|---:|
| ESP32 Dev Module | esp32:esp32 3.0.7 | Compilação e link concluídos | 968265 / 1310720 bytes (73%) | 56276 / 327680 bytes (17%) |
| UNO R4 WiFi | arduino:renesas_uno 1.5.1 | Compilação e link concluídos | 106016 / 262144 bytes (40%) | 19852 / 32768 bytes (60%) |

O core Renesas emite um aviso de metadados da própria biblioteca WDT (`renesas` versus `renesas_uno`); o build termina com sucesso. Permanecem necessários testes físicos do watchdog e do restante dos componentes.

Bibliotecas: ArduinoJson 7.4.2, DHT sensor library 1.4.6 e Adafruit Unified Sensor 1.1.15. LEDC 2.x tem ramo de compatibilidade, mas apenas a versão ESP32 3.0.7 foi efetivamente compilada nesta execução.

## Lógica C++

`tests/test_fsm.cpp` compilado com g++ e executado com sucesso. Verifica:

- Faixa e margem térmica, limites estritos de 20/30/60 s.
- Reconhecimento local e retenção da ventilação.
- Três falhas, recuperação e interrupção da comprovação térmica durante falha.
- Influência separada de luminosidade e vibração.
- Overflow do buffer com preservação da ordem das últimas 32 leituras.
- Confirmação atrasada sem remover outro registro e configurações inválidas.

## Servidor e simulador Python

**15 testes automatizados passaram** com `python -m unittest discover -s tests -v`.

Cobrem persistência SQLite, deduplicação e conflito de sequência, token por dispositivo, tipos/faixas rejeitados com log, ausência de NTP e DHT inválido, sessão/CSRF/perfis, envio/ACK de comandos, configuração não revertida pelo histórico, cadastro de dispositivos, timeout ONLINE, previsão e anomalia, indicadores sem preencher lacunas, namespace global de sequência, CSV, geração de relatório Markdown+PNG e reconhecimento no painel.

O teste de integração abre um servidor HTTP real em porta temporária, inicia `simulador_dispositivo.py` em outro processo e verifica duas leituras e o ACK do comando SET_INTERVALO. Não depende de uma placa conectada.

A disponibilidade histórica foi testada com união de janelas reais de comunicação, sem transformar reenvio offline em presença histórica.

O JavaScript passou na verificação sintática `node --check`. Os templates e as rotas foram exercitados por testes HTTP. Não houve revisão visual automatizada em navegador nesta execução.

## Limites da verificação

Não houve conexão física a ESP32/UNO, montagem elétrica, carga do firmware, teste na rede dos avaliadores, calibração de DHT/LDR, teste de relé/buzzer/RGB/matriz, validação NTP nem medição de latência do WiFiS3 no UNO. A compilação comprova compatibilidade do código com os cores/bibliotecas indicados, não o funcionamento de uma montagem ainda não feita.

A captura PCAP não foi fornecida, portanto a perícia não foi executada. Não foi criado repositório GitHub, acesso dos avaliadores ou histórico de commits. Essas pendências estão documentadas no README principal.
