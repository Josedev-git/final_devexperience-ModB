@echo off
setlocal
cd /d "%~dp0servidor"
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv
  if errorlevel 1 goto erro
)
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto erro
.venv\Scripts\python.exe preparar.py
if errorlevel 1 goto erro
start "" http://localhost:5000
.venv\Scripts\python.exe app.py
pause
exit /b
:erro
echo Falhou. Confira a mensagem acima e se o Python 3.10+ esta instalado.
pause
