@echo off
cd /d "%~dp0servidor"
.venv\Scripts\python.exe simulador_dispositivo.py --aquecimento
pause
