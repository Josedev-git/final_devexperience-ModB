"""Primeira execucao: gera .env e cadastro inicial sem editar segredos a mao."""
from pathlib import Path
import secrets
BASE=Path(__file__).resolve().parent
path=BASE/'.env'
if not path.exists():
    values={'APP_SECRET':secrets.token_hex(32),'ADMIN_PASSWORD':secrets.token_urlsafe(12),
            'OPERATOR_PASSWORD':secrets.token_urlsafe(12),'DEVICE_TOKEN':secrets.token_hex(24),
            'SIM_TOKEN':secrets.token_hex(24),'HOST':'0.0.0.0','PORT':'5000','COOKIE_SECURE':'0'}
    path.write_text('\n'.join(k+'='+v for k,v in values.items())+'\n')
    print('\nCONFIGURACAO CRIADA. Guarde estas credenciais locais:')
    print('Administrador: admin /',values['ADMIN_PASSWORD'])
    print('Operador: operador /',values['OPERATOR_PASSWORD'])
    print('Token da placa VG-CAM01:',values['DEVICE_TOKEN'])
else:
    print('Configuracao .env existente preservada.')
from app import create_app, initialize
initialize(create_app())
print('Banco SQLite pronto. Painel: http://localhost:5000')
print('Credenciais ficam no .env local. Nunca envie esse arquivo ao GitHub.\n')
