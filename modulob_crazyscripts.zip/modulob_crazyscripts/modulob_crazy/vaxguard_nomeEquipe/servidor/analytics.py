"""Modelos por janela temporal e indicadores com lacunas explicitas."""
import math
import json
import statistics


def analyze(db, device, timestamp, temp):
    if timestamp is None or temp is None:
        return False, None
    rows = db.execute('SELECT ts,temp FROM leituras WHERE device_id=? AND ts<? AND ts>=? AND temp IS NOT NULL AND anomala=0 ORDER BY ts DESC LIMIT 60',
                      (device['id'], timestamp, timestamp - 600)).fetchall()
    anomaly = False
    if len(rows) >= 6:
        values = [r['temp'] for r in rows]
        # Ajusta media/desvio usando apenas o historico anterior, sem vazamento.
        mean, std = statistics.mean(values), max(statistics.pstdev(values), .25)
        anomaly = abs(temp - mean) / std > 3.5 and abs(temp - rows[0]['temp']) > 2
    window = [(r['ts'], r['temp']) for r in rows if r['ts'] >= timestamp - 120]
    if not anomaly:
        window.append((timestamp, temp))
    if anomaly or len(window) < 6 or max(x[0] for x in window) - min(x[0] for x in window) < 30:
        return anomaly, None
    xs = [x - timestamp for x, _ in window]
    ys = [y for _, y in window]
    mx, my = statistics.mean(xs), statistics.mean(ys)
    divisor = sum((x - mx)**2 for x in xs)
    slope = sum((x - mx)*(y - my) for x, y in zip(xs, ys)) / divisor if divisor else 0
    fitted_now = my - slope * mx
    limit = device['temp_max'] if slope > 0 else device['temp_min']
    eta = (limit - fitted_now) / slope / 60 if abs(slope) > 1e-6 else None
    if eta is None or eta < 0 or not device['temp_min'] <= temp <= device['temp_max']:
        return anomaly, None
    return anomaly, eta if eta <= 1440 else None


def indicators(rows, start, end, interval_ms, low, high):
    """Estima duracoes por amostragem; nao preenche lacunas >3 intervalos."""
    valid = [r['temp'] for r in rows if r['temp'] is not None]
    known = outside = 0.0
    openings = 0
    opened = None
    durations = []
    previous_door = None
    for i, row in enumerate(rows):
        stamp = row['ts'] if row['ts'] is not None else row['recebido_em']
        next_stamp = ((rows[i+1]['ts'] if rows[i+1]['ts'] is not None else rows[i+1]['recebido_em'])
                      if i + 1 < len(rows) else end)
        snapshot = json.loads(row['payload']) if 'payload' in row.keys() else {}
        row_interval = snapshot.get('intervalo_ms', interval_ms)
        row_low, row_high = snapshot.get('temp_min', low), snapshot.get('temp_max', high)
        # Ultima leitura e mantida por ate um intervalo; demais por no maximo tres.
        cap = row_interval / 1000 * (3 if i + 1 < len(rows) else 1)
        dt = max(0, min(end, next_stamp, stamp + cap) - max(start, stamp))
        known += dt
        if row['temp'] is not None and not row_low <= row['temp'] <= row_high:
            outside += dt
        if previous_door is not None and row['porta'] == 1 and previous_door == 0:
            openings += 1
            opened = stamp
        if row['porta'] == 0 and opened is not None:
            durations.append(stamp - opened)
            opened = None
        # Uma lacuna torna a abertura incompleta; nao inventa duracao.
        if next_stamp - stamp > 3 * row_interval / 1000:
            opened, previous_door = None, None
        else:
            previous_door = row['porta']
    return {'fora_faixa_s': round(outside, 1), 'aberturas_porta': openings,
            'media_porta_aberta_s': round(statistics.mean(durations), 1) if durations else None,
            'cobertura_dados_pct': round(min(100, known / max(1, end - start) * 100), 2),
            'temp_min': min(valid) if valid else None,
            'temp_media': round(statistics.mean(valid), 2) if valid else None,
            'temp_max': max(valid) if valid else None,
            'leituras': len(rows)}


def online_availability(heartbeats,start,end):
    """Uniao das janelas ONLINE: cada contato vale por tres intervalos."""
    covered=0.0
    cursor=start
    for row in heartbeats:
        left=max(start,row['ts'])
        right=min(end,row['ts']+3*row['intervalo_ms']/1000)
        covered+=max(0,right-max(left,cursor))
        cursor=max(cursor,right)
    return round(min(100,covered/max(1,end-start)*100),2)
