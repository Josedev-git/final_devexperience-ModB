"""VG-CAM02: telemetria, aquecimento, eventos e consumo de comandos reais."""
import argparse
import json
import math
import os
from pathlib import Path
import random
import time
import urllib.request
from dotenv import load_dotenv
BASE=Path(__file__).resolve().parent
load_dotenv(BASE/'.env')


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--url',default='http://127.0.0.1:5000')
    parser.add_argument('--aquecimento',action='store_true')
    parser.add_argument('--passo',type=float,default=.08,help='Celsius por leitura')
    args=parser.parse_args()
    token=os.getenv('SIM_TOKEN')
    if not token:
        raise SystemExit('Execute preparar.py primeiro.')
    path=BASE/'.sim_state.json'
    state=json.loads(path.read_text()) if path.exists() else {'seq':0,'cmd':0,'low':2,'high':8,'interval':5}
    temperature=5.0
    status='NORMAL'
    outside=None
    manual=False
    def save():
        tmp=path.with_suffix('.tmp')
        tmp.write_text(json.dumps(state))
        tmp.replace(path)
    def exchange(method,route,payload=None):
        req=urllib.request.Request(args.url+route,data=json.dumps(payload).encode() if payload is not None else None,
             headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method=method)
        with urllib.request.urlopen(req,timeout=4) as response:
            raw=response.read()
            return json.loads(raw) if raw else {}
    pending=[]
    def emit(route,extra):
        state['seq']+=1
        save()
        packet={'device_id':'VG-CAM02','placa':'ESP32','seq':state['seq'],'ts':int(time.time())}
        packet.update(extra)
        pending.append((route,packet))
        if len(pending)>128:
            pending.pop(0)
    print('VG-CAM02 iniciado. Ctrl+C encerra.')
    while True:
        if args.aquecimento:
            temperature+=args.passo if not manual else -.12
        else:
            temperature=5+random.uniform(-.15,.15)
        now=time.monotonic()
        if temperature<state['low'] or temperature>state['high']:
            outside=now if outside is None else outside
        else:
            outside=None
        new='CRITICO' if outside is not None and now-outside>30 else ('ATENCAO' if temperature<state['low']+1 or temperature>state['high']-1 else 'NORMAL')
        if new!=status:
            emit('/api/eventos',{'tipo':'MUDANCA_ESTADO','anterior':status,'novo':new,'motivo':'Simulacao termica'})
            status=new
        emit('/api/telemetria',{'temp':round(max(-40,min(80,temperature)),2),'umid':50,'porta':0,'estado':status,
                              'luz_pct':15,'vibracao':0,'temp_min':state['low'],'temp_max':state['high'],'intervalo_ms':int(state['interval']*1000)})
        try:
            # Envia o historico antes de buscar comandos; preserva ordem por seq.
            while pending:
                route,packet=pending[0]
                exchange('POST',route,packet)
                pending.pop(0)
            response=exchange('GET','/api/dispositivos/VG-CAM02/comandos?apos='+str(state['cmd']))
            for command in response['comandos']:
                kind=command['comando']
                params=command['parametros']
                if kind=='SET_LIMITES':
                    state.update(low=params['temp_min'],high=params['temp_max'])
                    outside=None
                elif kind=='SET_INTERVALO':
                    state['interval']=params['intervalo_ms']/1000
                elif kind=='VENTILACAO_ON':
                    manual=True
                elif kind=='VENTILACAO_OFF':
                    manual=False
                elif kind=='REINICIAR':
                    temperature,status,outside,manual=5,'NORMAL',None,False
                state['cmd']=command['id']
                save()
                emit('/api/eventos',{'tipo':'COMANDO_EXECUTADO','command_id':command['id'],'motivo':'Comando aplicado pelo simulador'})
            print(status,'%.2f C'%temperature,'pendentes',len(pending))
        except (OSError,ValueError) as exc:
            print('Rede indisponivel:',exc)
        time.sleep(state['interval'])  # Permitido no simulador de PC; nao e o firmware.


if __name__=='__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('\nSimulador encerrado.')
