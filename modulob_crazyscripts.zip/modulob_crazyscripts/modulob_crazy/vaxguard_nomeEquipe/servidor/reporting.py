import io
import json
import zipfile
from datetime import datetime, timezone
import matplotlib
matplotlib.use('Agg')
from matplotlib.figure import Figure


def utc(value):
    return datetime.fromtimestamp(value,timezone.utc).strftime('%d/%m/%Y %H:%M:%S UTC')


def build_report(device, rows, kpis, start, end):
    valid = [r for r in rows if r['temp'] is not None]
    fig = Figure(figsize=(10,4),layout='constrained')
    ax = fig.subplots()
    if rows:
        dates=[datetime.fromtimestamp(r['ts'] or r['recebido_em'],timezone.utc) for r in rows]
        snapshots=[json.loads(r['payload']) for r in rows]
        ax.fill_between(dates,[p.get('temp_min',device['temp_min']) for p in snapshots],
                        [p.get('temp_max',device['temp_max']) for p in snapshots],
                        color='#d4f1e7',step='post',label='Faixa registrada')
    else:
        ax.axhspan(device['temp_min'],device['temp_max'],color='#d4f1e7',label='Faixa cadastrada')
    if rows:
        xs,ys=[],[]
        previous=None
        for row in rows:
            stamp=row['ts'] or row['recebido_em']
            if previous is not None and stamp-previous>3*device['intervalo_ms']/1000:
                xs.append(datetime.fromtimestamp(stamp,timezone.utc));ys.append(float('nan'))
            xs.append(datetime.fromtimestamp(stamp,timezone.utc))
            ys.append(row['temp'] if row['temp'] is not None else float('nan'))
            previous=stamp
        ax.plot(xs,ys,color='#0c766e',linewidth=1.5,label='Temperatura')
    ax.set(title='VaxGuard Connect — '+device['id'],ylabel='Temperatura (°C)',xlabel='Data e hora UTC')
    ax.legend(loc='best')
    ax.grid(alpha=.2)
    image = io.BytesIO()
    fig.savefig(image,format='png',dpi=160)
    excursions=[]
    current=None
    for row in rows:
        stamp=row['ts'] or row['recebido_em']
        snapshot=json.loads(row['payload'])
        low,high=snapshot.get('temp_min',device['temp_min']),snapshot.get('temp_max',device['temp_max'])
        outside=row['temp'] is not None and not low<=row['temp']<=high
        if current and stamp-current['last']>3*snapshot.get('intervalo_ms',device['intervalo_ms'])/1000:
            excursions.append(current)
            current=None
        if outside:
            if current is None:
                current={'inicio':stamp,'last':stamp,'fim':None,'min':row['temp'],'max':row['temp']}
            current.update(last=stamp,min=min(current['min'],row['temp']),max=max(current['max'],row['temp']))
        elif current:
            current['fim']=stamp if row['temp'] is not None else None
            excursions.append(current)
            current=None
    if current:
        excursions.append(current)
    lines=['# Relatório de conformidade — VaxGuard Connect','',
           '**Dispositivo:** '+device['id'],'','**Placa:** '+device['placa'],'',
           '**Período:** '+utc(start)+' até '+utc(end),'',
           '**Faixa cadastrada no momento da emissão:** %.1f–%.1f °C'%(device['temp_min'],device['temp_max']),'',
           '| Indicador | Valor |','|---|---|']
    labels={'fora_faixa_s':'Tempo estimado fora da faixa (s)','aberturas_porta':'Aberturas observadas',
            'media_porta_aberta_s':'Duração média de aberturas completas (s)',
            'disponibilidade_pct':'Disponibilidade estimada ONLINE (%)','cobertura_dados_pct':'Cobertura de dados no período (%)','temp_min':'Temperatura mínima (°C)',
            'temp_media':'Temperatura média (°C)','temp_max':'Temperatura máxima (°C)','leituras':'Leituras'}
    for key,value in kpis.items():
        lines.append('| %s | %s |'%(labels[key],value if value is not None else 'Sem dados'))
    lines+=['','![Temperatura e faixa ideal](grafico.png)','','## Excursões observadas','',
            '| Início UTC | Retorno UTC | Mín. °C | Máx. °C |','|---|---|---|---|']
    for item in excursions:
        lines.append('| %s | %s | %.2f | %.2f |'%(utc(item['inicio']),utc(item['fim']) if item['fim'] else 'Não comprovado no período',item['min'],item['max']))
    if not excursions:
        lines.append('| Nenhuma excursão observada | — | — | — |')
    lines+=['','## Método e limites','',
            'Indicadores estimados por amostragem. Lacunas acima de três intervalos não são preenchidas; a última leitura cobre no máximo um intervalo. Aberturas já em andamento no início e ainda abertas no fim não entram na média.',
            '', 'A disponibilidade histórica usa contatos HTTP realmente recebidos e a regra ONLINE de três intervalos. A cobertura de dados é separada: reenvio offline recupera amostras sem reclassificar a rede como online no passado. As janelas de presença têm resolução de um segundo.',
            '', 'Dados sem NTP usam horário de recebimento e não comprovam o horário original. Os indicadores e o gráfico usam os limites e intervalos registrados em cada amostra; para registros de clientes antigos que não enviaram esses campos, usam a configuração atual como aproximação. Não substitui calibração, validação metrológica nem atestado regulatório.',
            '', 'Gerado em '+utc(__import__('time').time())+'.']
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('relatorio.md','\n'.join(lines))
        z.writestr('grafico.png',image.getvalue())
    return output.getvalue()
