PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS usuarios(id INTEGER PRIMARY KEY, nome TEXT UNIQUE NOT NULL, senha_hash TEXT NOT NULL, perfil TEXT NOT NULL CHECK(perfil IN ('OPERADOR','ADMINISTRADOR')));
CREATE TABLE IF NOT EXISTS dispositivos(id TEXT PRIMARY KEY, placa TEXT NOT NULL, token_hash TEXT NOT NULL UNIQUE, temp_min REAL NOT NULL DEFAULT 2, temp_max REAL NOT NULL DEFAULT 8, intervalo_ms INTEGER NOT NULL DEFAULT 5000, config_seq INTEGER NOT NULL DEFAULT 0, criado_em REAL NOT NULL, ultimo_recebido REAL);
CREATE TABLE IF NOT EXISTS registros(device_id TEXT NOT NULL REFERENCES dispositivos(id), seq INTEGER NOT NULL, hash TEXT NOT NULL, PRIMARY KEY(device_id,seq));
CREATE TABLE IF NOT EXISTS leituras(id INTEGER PRIMARY KEY, device_id TEXT NOT NULL REFERENCES dispositivos(id), seq INTEGER NOT NULL, ts REAL, recebido_em REAL NOT NULL, temp REAL, umid REAL, porta INTEGER NOT NULL, estado TEXT NOT NULL, luz_pct REAL NOT NULL, vibracao INTEGER NOT NULL, anomala INTEGER NOT NULL DEFAULT 0, risco_min REAL, payload TEXT NOT NULL, UNIQUE(device_id,seq));
CREATE INDEX IF NOT EXISTS leitura_tempo ON leituras(device_id,ts);
CREATE TABLE IF NOT EXISTS eventos(id INTEGER PRIMARY KEY, device_id TEXT NOT NULL REFERENCES dispositivos(id), seq INTEGER, ts REAL, recebido_em REAL NOT NULL, tipo TEXT NOT NULL, anterior TEXT, novo TEXT, motivo TEXT NOT NULL, reconhecido_por INTEGER REFERENCES usuarios(id), reconhecido_em REAL, command_id INTEGER, UNIQUE(device_id,seq));
CREATE TABLE IF NOT EXISTS comandos(id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT NOT NULL REFERENCES dispositivos(id), comando TEXT NOT NULL, parametros TEXT NOT NULL, criado_em REAL NOT NULL, criado_por INTEGER REFERENCES usuarios(id), status TEXT NOT NULL DEFAULT 'PENDENTE', resultado TEXT);

CREATE TABLE IF NOT EXISTS presencas(device_id TEXT NOT NULL REFERENCES dispositivos(id), ts INTEGER NOT NULL, intervalo_ms INTEGER NOT NULL, PRIMARY KEY(device_id,ts));
