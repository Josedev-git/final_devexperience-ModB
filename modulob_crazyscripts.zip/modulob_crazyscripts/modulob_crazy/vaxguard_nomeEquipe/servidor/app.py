import csv
import hashlib
import hmac
import io
import json
import logging
import math
import os
from pathlib import Path
import re
import secrets
import sqlite3
import time
from datetime import datetime, timezone, timedelta
from functools import wraps
from flask import Flask, abort, g, jsonify, redirect, render_template, request, session, url_for, send_file
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash
from analytics import analyze, indicators, online_availability

BASE = Path(__file__).resolve().parent
load_dotenv(BASE / '.env')
STATES = {'NORMAL','ATENCAO','CRITICO','RECONHECIDO','FALHA_SENSOR'}
KINDS = {'VENTILACAO_ON','VENTILACAO_OFF','SET_LIMITES','SET_INTERVALO','REINICIAR'}


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.update(SECRET_KEY=os.getenv('APP_SECRET'), DATABASE=str(BASE / 'vaxguard.sqlite3'),
                      MAX_CONTENT_LENGTH=16384, SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE='Lax', SESSION_COOKIE_SECURE=os.getenv('COOKIE_SECURE') == '1',
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=8))
    if overrides:
        app.config.update(overrides)
    if not app.config['SECRET_KEY']:
        raise RuntimeError('Execute python preparar.py para gerar o .env automaticamente.')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(app.config['DATABASE'], timeout=10)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys=ON')
            g.db.execute('PRAGMA journal_mode=WAL')
        return g.db

    @app.teardown_appcontext
    def close(_):
        if 'db' in g:
            g.pop('db').close()

    def user_required(admin=False):
        def decorate(fn):
            @wraps(fn)
            def wrapped(*args, **kwargs):
                user = db().execute('SELECT * FROM usuarios WHERE id=?', (session.get('uid'),)).fetchone()
                if user is None:
                    if request.path.startswith('/painel/api'):
                        abort(401)
                    return redirect(url_for('login'))
                if admin and user['perfil'] != 'ADMINISTRADOR':
                    abort(403)
                g.user = user
                return fn(*args, **kwargs)
            return wrapped
        return decorate

    def device_auth(device_id=None):
        token = request.headers.get('Authorization', '')
        if not token.startswith('Bearer ') or len(token) > 256:
            abort(401)
        hashed = digest(token[7:])
        row = db().execute('SELECT * FROM dispositivos WHERE token_hash=?', (hashed,)).fetchone()
        if row is None or not hmac.compare_digest(row['token_hash'], hashed) or (device_id and row['id'] != device_id):
            abort(401)
        return row

    def record_presence(device_id,now):
        interval=db().execute('SELECT intervalo_ms FROM dispositivos WHERE id=?',(device_id,)).fetchone()[0]
        db().execute('INSERT OR REPLACE INTO presencas(device_id,ts,intervalo_ms) VALUES(?,?,?)',(device_id,int(now),interval))
        db().execute('UPDATE dispositivos SET ultimo_recebido=? WHERE id=?',(now,device_id))

    def availability(device_id,start,end):
        contacts=db().execute('SELECT * FROM presencas WHERE device_id=? AND ts>=? AND ts<=? ORDER BY ts',(device_id,start-180,end)).fetchall()
        return online_availability(contacts,start,end)

    @app.before_request
    def csrf():
        if request.method == 'POST' and not request.path.startswith('/api/'):
            supplied = request.headers.get('X-CSRF-Token') or request.form.get('csrf', '')
            expected = session.get('csrf', '')
            if not expected or not hmac.compare_digest(supplied, expected):
                abort(400, 'CSRF invalido; atualize a pagina.')

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Cache-Control'] = 'no-store'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'"
        return response

    @app.errorhandler(400)
    @app.errorhandler(401)
    @app.errorhandler(403)
    @app.errorhandler(409)
    @app.errorhandler(413)
    def rejected(error):
        app.logger.warning('Rejeitado status=%s rota=%s origem=%s motivo=%s', error.code, request.path, request.remote_addr, error.description)
        return jsonify(erro=str(error.description)), error.code

    @app.get('/saude')
    def health():
        return {'status': 'ok'}

    @app.route('/login', methods=['GET','POST'])
    def login():
        session.setdefault('csrf', secrets.token_hex(24))
        error = None
        if request.method == 'POST':
            # Limite simples em memoria por origem; duracao maxima e cardinalidade limitada.
            key = request.remote_addr
            attempts = app.extensions.setdefault('login_attempts', {})
            now = time.time()
            for stale in [k for k, v in attempts.items() if now - v[0] > 600]:
                attempts.pop(stale, None)
            first, count = attempts.get(key, (now, 0))
            if count >= 10:
                return render_template('login.html', error='Muitas tentativas. Aguarde 10 minutos.'), 429
            row = db().execute('SELECT * FROM usuarios WHERE nome=?', (request.form.get('nome',''),)).fetchone()
            if row and check_password_hash(row['senha_hash'], request.form.get('senha','')):
                session.clear()
                session.update(uid=row['id'], csrf=secrets.token_hex(24))
                session.permanent = True
                attempts.pop(key, None)
                return redirect(url_for('dashboard'))
            if len(attempts) < 4096 or key in attempts:
                attempts[key] = (first, count + 1)
            error = 'Usuario ou senha incorretos.'
        return render_template('login.html', error=error)

    @app.post('/logout')
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.get('/')
    @user_required()
    def dashboard():
        return render_template('dashboard.html', user=g.user)

    def number(data, key, low, high, nullable=False):
        value = data.get(key)
        if value is None and nullable:
            return None
        if isinstance(value, bool) or not isinstance(value, (int,float)) or not math.isfinite(value) or not low <= value <= high:
            abort(400, 'Campo invalido: ' + key)
        return value

    def integer(data, key, low, high):
        value = number(data, key, low, high)
        if not isinstance(value, int):
            abort(400, 'Campo deve ser inteiro: ' + key)
        return value

    def text(data, key, max_length, required=True):
        val = data.get(key)
        if val is None and not required:
            return None
        if not isinstance(val, str) or not val or len(val) > max_length:
            abort(400, 'Texto invalido: ' + key)
        return val

    @app.post('/api/telemetria')
    @app.post('/api/eventos')
    def ingest():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            abort(400, 'JSON deve ser um objeto')
        device = device_auth(text(data, 'device_id', 40))
        seq = integer(data, 'seq', 1, 9007199254740991)
        if data.get('placa') not in ('ESP32','UNO R4 WiFi') or data['placa'] != device['placa']:
            abort(400, 'Placa diferente do cadastro')
        now = time.time()
        ts = number(data, 'ts', 1704067200, now + 120, nullable=True)
        tele = request.path.endswith('telemetria')
        if tele:
            temp = number(data, 'temp', -40, 80, nullable=True)
            humidity = number(data, 'umid', 0, 100, nullable=True)
            if (temp is None) != (humidity is None):
                abort(400, 'Temperatura e umidade devem falhar juntas')
            door = integer(data, 'porta', 0, 1)
            vibration = integer(data, 'vibracao', 0, 1)
            light = number(data, 'luz_pct', 0, 100)
            if data.get('estado') not in STATES:
                abort(400, 'Estado desconhecido')
        else:
            kind = text(data, 'tipo', 40)
            reason = text(data, 'motivo', 240)
            for field in ('anterior','novo'):
                if data.get(field) is not None and data[field] not in STATES:
                    abort(400, 'Estado de evento invalido')
            if kind in ('MUDANCA_ESTADO','SENSOR_FALHA') and not all(data.get(k) in STATES for k in ('anterior','novo')):
                abort(400, 'Mudanca exige anterior e novo')
            cid = data.get('command_id')
            if cid is not None:
                integer(data, 'command_id', 1, 2147483646)
                if not db().execute('SELECT 1 FROM comandos WHERE id=? AND device_id=?', (cid, device['id'])).fetchone():
                    abort(400, 'Comando nao pertence ao dispositivo')
        config_snapshot = None
        if tele and any(k in data for k in ('temp_min','temp_max','intervalo_ms')):
            low = number(data,'temp_min',-40,80)
            high = number(data,'temp_max',-40,80)
            interval = integer(data,'intervalo_ms',2000,60000)
            if high-low <= 2:
                abort(400,'Faixa de configuracao invalida')
            config_snapshot = (low,high,interval)
        raw = json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=True)
        record_hash = digest(request.path + raw)
        connection = db()
        connection.execute('BEGIN IMMEDIATE')
        try:
            old = connection.execute('SELECT hash FROM registros WHERE device_id=? AND seq=?', (device['id'],seq)).fetchone()
            if old:
                if old['hash'] != record_hash:
                    abort(409, 'Sequencia reutilizada com conteudo diferente')
                record_presence(device['id'],now)
                connection.commit()
                return {'ok': True, 'duplicado': True}
            connection.execute('INSERT INTO registros VALUES(?,?,?)', (device['id'],seq,record_hash))
            if tele:
                if config_snapshot and seq > device['config_seq']:
                    connection.execute('UPDATE dispositivos SET temp_min=?,temp_max=?,intervalo_ms=?,config_seq=? WHERE id=?', (*config_snapshot,seq,device['id']))
                    device = connection.execute('SELECT * FROM dispositivos WHERE id=?',(device['id'],)).fetchone()
                anomaly, eta = analyze(connection, device, ts, temp)
                connection.execute('INSERT INTO leituras(device_id,seq,ts,recebido_em,temp,umid,porta,estado,luz_pct,vibracao,anomala,risco_min,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                                   (device['id'],seq,ts,now,temp,humidity,door,data['estado'],light,vibration,int(anomaly),eta,raw))
                alerts = []
                if anomaly:
                    alerts.append(('ANOMALIA','Salto termico anomalo pelo z-score movel'))
                if eta is not None and 0 <= eta < 5 and data['estado'] not in ('CRITICO','RECONHECIDO','FALHA_SENSOR'):
                    alerts.append(('RISCO_EXCURSAO', 'RISCO DE EXCURSAO em %.2f minutos' % eta))
                for typ, message in alerts:
                    # Historico reenviado nao e confundido com alerta atual; timestamp e da amostra.
                    exists = connection.execute('SELECT 1 FROM eventos WHERE device_id=? AND tipo=? AND ts>=? AND ts<=?',
                                                (device['id'],typ,ts-60,ts+60)).fetchone()
                    if not exists:
                        connection.execute('INSERT INTO eventos(device_id,ts,recebido_em,tipo,motivo) VALUES(?,?,?,?,?)', (device['id'],ts,now,typ,message))
            else:
                connection.execute('INSERT INTO eventos(device_id,seq,ts,recebido_em,tipo,anterior,novo,motivo,command_id) VALUES(?,?,?,?,?,?,?,?,?)',
                                   (device['id'],seq,ts,now,kind,data.get('anterior'),data.get('novo'),reason,cid))
                if cid and kind in ('COMANDO_EXECUTADO','COMANDO_REJEITADO'):
                    connection.execute('UPDATE comandos SET status=?,resultado=? WHERE id=? AND device_id=?',
                                       ('EXECUTADO' if kind == 'COMANDO_EXECUTADO' else 'REJEITADO',reason,cid,device['id']))
                    if kind == 'COMANDO_EXECUTADO':
                        command = connection.execute('SELECT * FROM comandos WHERE id=?', (cid,)).fetchone()
                        params = json.loads(command['parametros'])
                        if command['comando'] == 'SET_LIMITES':
                            connection.execute('UPDATE dispositivos SET temp_min=?,temp_max=?,config_seq=? WHERE id=? AND config_seq<?', (params['temp_min'],params['temp_max'],seq,device['id'],seq))
                        if command['comando'] == 'SET_INTERVALO':
                            connection.execute('UPDATE dispositivos SET intervalo_ms=?,config_seq=? WHERE id=? AND config_seq<?', (params['intervalo_ms'],seq,device['id'],seq))
            record_presence(device['id'],now)
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        return {'ok': True}, 201

    @app.get('/api/dispositivos/<device_id>/comandos')
    def poll_commands(device_id):
        device_auth(device_id)
        try:
            cursor = int(request.args.get('apos', '0'))
            if not 0 <= cursor < 2147483647:
                raise ValueError()
        except ValueError:
            abort(400, 'Cursor invalido')
        # Confirmacao cumulativa recupera ACK perdido em reboot; aplicacao exige IDs ordenados.
        with db():
            db().execute("UPDATE comandos SET status='CONFIRMADO_CURSOR' WHERE device_id=? AND id<=? AND status='PENDENTE'", (device_id,cursor))
            record_presence(device_id,time.time())
        rows = db().execute("SELECT id,comando,parametros FROM comandos WHERE device_id=? AND id>? AND status='PENDENTE' ORDER BY id LIMIT 1", (device_id,cursor)).fetchall()
        return {'comandos': [{'id':r['id'],'comando':r['comando'],'parametros':json.loads(r['parametros'])} for r in rows]}

    def period():
        try:
            end = float(request.args.get('fim', time.time()))
            start = float(request.args.get('inicio', end - 3600))
            if not all(math.isfinite(x) for x in (start,end)) or start >= end or end - start > 31*86400:
                raise ValueError()
        except ValueError:
            abort(400, 'Periodo invalido; maximo 31 dias')
        return start,end

    def reading_rows(device, start, end):
        return db().execute('SELECT * FROM leituras WHERE device_id=? AND COALESCE(ts,recebido_em) BETWEEN ? AND ? ORDER BY COALESCE(ts,recebido_em),seq', (device,start,end)).fetchall()

    @app.get('/painel/api/dados')
    @user_required()
    def panel_data():
        start,end = period()
        devices = []
        for dev in db().execute('SELECT * FROM dispositivos ORDER BY id'):
            item = {k:dev[k] for k in ('id','placa','temp_min','temp_max','intervalo_ms','ultimo_recebido')}
            rows = reading_rows(dev['id'],start,end)
            item['online'] = dev['ultimo_recebido'] is not None and time.time() - dev['ultimo_recebido'] <= 3*dev['intervalo_ms']/1000
            item['kpis'] = indicators(rows,start,end,dev['intervalo_ms'],dev['temp_min'],dev['temp_max'])
            item['kpis']['disponibilidade_pct'] = availability(dev['id'],start,end)
            item['leituras'] = [dict(r) for r in rows[-720:]]
            latest = db().execute('SELECT * FROM leituras WHERE device_id=? ORDER BY COALESCE(ts,recebido_em) DESC,seq DESC LIMIT 1', (dev['id'],)).fetchone()
            item['atual'] = dict(latest) if latest else None
            devices.append(item)
        events = [dict(r) for r in db().execute('SELECT * FROM eventos WHERE COALESCE(ts,recebido_em) BETWEEN ? AND ? ORDER BY COALESCE(ts,recebido_em) DESC LIMIT 200', (start,end))]
        commands = [dict(r) for r in db().execute('SELECT * FROM comandos ORDER BY id DESC LIMIT 20')]
        return {'dispositivos':devices,'eventos':events,'comandos':commands,'inicio':start,'fim':end}

    @app.post('/painel/api/eventos/<int:event_id>/reconhecer')
    @user_required()
    def acknowledge(event_id):
        with db():
            found = db().execute('UPDATE eventos SET reconhecido_por=?,reconhecido_em=? WHERE id=?', (g.user['id'],time.time(),event_id))
            if not found.rowcount:
                abort(404)
        # Reconhecimento no painel registra ciencia, nao silencia fisicamente a placa.
        return {'ok':True}

    @app.post('/painel/api/comandos')
    @user_required(admin=True)
    def enqueue_command():
        data = request.get_json(silent=True)
        if not isinstance(data,dict):
            abort(400,'JSON invalido')
        device = db().execute('SELECT * FROM dispositivos WHERE id=?',(text(data,'device_id',40),)).fetchone()
        if device is None or data.get('comando') not in KINDS:
            abort(400,'Dispositivo ou comando invalido')
        kind = data['comando']
        args = data.get('parametros',{})
        if not isinstance(args,dict):
            abort(400,'Parametros invalidos')
        if kind == 'SET_LIMITES':
            if set(args) != {'temp_min','temp_max'}:
                abort(400,'Informe os dois limites')
            low = number(args,'temp_min',-40,80)
            high = number(args,'temp_max',-40,80)
            if high-low <= 2:
                abort(400,'Faixa deve ser maior que 2 C')
        elif kind == 'SET_INTERVALO':
            if set(args) != {'intervalo_ms'}:
                abort(400,'Informe intervalo_ms')
            integer(args,'intervalo_ms',2000,60000)
        elif args:
            abort(400,'Comando nao recebe parametros')
        with db():
            cur = db().execute('INSERT INTO comandos(device_id,comando,parametros,criado_em,criado_por) VALUES(?,?,?,?,?)', (device['id'],kind,json.dumps(args),time.time(),g.user['id']))
        return {'ok':True,'id':cur.lastrowid},201

    @app.post('/painel/api/dispositivos')
    @user_required(admin=True)
    def register_device():
        data = request.get_json(silent=True)
        if not isinstance(data,dict):
            abort(400,'JSON invalido')
        identifier = text(data,'id',40)
        if not re.fullmatch(r'[A-Za-z0-9_-]+',identifier) or data.get('placa') not in ('ESP32','UNO R4 WiFi'):
            abort(400,'ID ou placa invalida')
        token = secrets.token_urlsafe(32)
        try:
            with db():
                db().execute('INSERT INTO dispositivos(id,placa,token_hash,criado_em) VALUES(?,?,?,?)', (identifier,data['placa'],digest(token),time.time()))
        except sqlite3.IntegrityError:
            abort(409,'ID ja cadastrado')
        return {'id':identifier,'token':token},201

    @app.get('/painel/eventos.csv')
    @user_required()
    def export_events():
        start,end = period()
        stream = io.StringIO(newline='')
        writer = csv.writer(stream)
        writer.writerow(['dispositivo','horario_utc','tipo','anterior','novo','motivo','reconhecido_por'])
        for row in db().execute('SELECT * FROM eventos WHERE COALESCE(ts,recebido_em) BETWEEN ? AND ? ORDER BY COALESCE(ts,recebido_em)',(start,end)):
            # Neutraliza formulas em programas de planilha.
            values = [row['device_id'],datetime.fromtimestamp(row['ts'] or row['recebido_em'],timezone.utc).isoformat(),row['tipo'],row['anterior'],row['novo'],row['motivo'],row['reconhecido_por']]
            writer.writerow(["'"+v if isinstance(v,str) and v.startswith(('=','+','-','@')) else v for v in values])
        return send_file(io.BytesIO(stream.getvalue().encode('utf-8-sig')),mimetype='text/csv',as_attachment=True,download_name='eventos.csv')

    @app.get('/painel/relatorio/<device_id>')
    @user_required()
    def report(device_id):
        from reporting import build_report
        start,end = period()
        dev = db().execute('SELECT * FROM dispositivos WHERE id=?',(device_id,)).fetchone()
        if dev is None:
            abort(404)
        rows = reading_rows(device_id,start,end)
        kpis = indicators(rows,start,end,dev['intervalo_ms'],dev['temp_min'],dev['temp_max'])
        kpis['disponibilidade_pct'] = availability(device_id,start,end)
        output = build_report(dict(dev),rows,kpis,start,end)
        return send_file(io.BytesIO(output),mimetype='application/zip',as_attachment=True,download_name='relatorio_'+device_id+'.zip')

    @app.cli.command('init-db')
    def init_db():
        initialize(app)

    return app


def initialize(app):
    with sqlite3.connect(app.config['DATABASE']) as connection:
        connection.executescript((BASE/'schema.sql').read_text())
        for name, role, variable in [('admin','ADMINISTRADOR','ADMIN_PASSWORD'),('operador','OPERADOR','OPERATOR_PASSWORD')]:
            password = os.getenv(variable)
            if password and not connection.execute('SELECT 1 FROM usuarios WHERE nome=?',(name,)).fetchone():
                connection.execute('INSERT INTO usuarios(nome,senha_hash,perfil) VALUES(?,?,?)',(name,generate_password_hash(password),role))
        for identifier, variable in [('VG-CAM01','DEVICE_TOKEN'),('VG-CAM02','SIM_TOKEN')]:
            token = os.getenv(variable)
            if token:
                connection.execute('INSERT OR IGNORE INTO dispositivos(id,placa,token_hash,criado_em) VALUES(?,?,?,?)',(identifier,'ESP32',digest(token),time.time()))


if __name__ == '__main__':
    application = create_app()
    initialize(application)
    application.run(host=os.getenv('HOST','0.0.0.0'),port=int(os.getenv('PORT','5000')),debug=False)
