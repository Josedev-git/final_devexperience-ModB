"""Integracao com servidor HTTP real e processo do simulador em pasta temporaria."""
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'servidor'))
from app import create_app,initialize,digest
from werkzeug.serving import make_server


class SimulatorTest(unittest.TestCase):
    def test_simulator_receives_command_and_sends_ack(self):
        with tempfile.TemporaryDirectory() as temp:
            database=str(Path(temp)/'live.db')
            app=create_app({'TESTING':True,'SECRET_KEY':'test-only','DATABASE':database})
            initialize(app)
            with sqlite3.connect(database) as db:
                db.execute('INSERT OR REPLACE INTO dispositivos(id,placa,token_hash,criado_em) VALUES(?,?,?,?)',('VG-CAM02','ESP32',digest('sim-test'),time.time()))
                db.execute('INSERT INTO comandos(device_id,comando,parametros,criado_em) VALUES(?,?,?,?)',('VG-CAM02','SET_INTERVALO','{"intervalo_ms":2000}',time.time()))
            server=make_server('127.0.0.1',0,app,threaded=True)
            thread=threading.Thread(target=server.serve_forever,daemon=True)
            thread.start()
            script=Path(temp)/'simulador_dispositivo.py'
            shutil.copy(Path(__file__).resolve().parents[1]/'servidor/simulador_dispositivo.py',script)
            env=dict(os.environ,SIM_TOKEN='sim-test')
            process=subprocess.Popen([sys.executable,str(script),'--url','http://127.0.0.1:'+str(server.server_port),'--aquecimento'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            try:
                success=False
                deadline=time.monotonic()+12
                while time.monotonic()<deadline:
                    with sqlite3.connect(database) as db:
                        count=db.execute("SELECT count(*) FROM leituras WHERE device_id='VG-CAM02'").fetchone()[0]
                        status=db.execute('SELECT status FROM comandos ORDER BY id DESC LIMIT 1').fetchone()[0]
                        if count>=2 and status=='EXECUTADO':
                            success=True
                            break
                    if process.poll() is not None:
                        self.fail(process.stderr.read().decode())
                    time.sleep(.1)
                self.assertTrue(success,'Simulador nao confirmou comando no prazo')
            finally:
                process.terminate()
                process.communicate(timeout=5)
                server.shutdown()
                server.server_close()
                thread.join(timeout=2)

if __name__=='__main__':
    unittest.main()
