#include "../firmware/vaxguard/core.h"
#include <cassert>
#include <iostream>
int main(){
 Config c;Inputs in;Machine m;assert(validConfig(c));
 assert(m.sample(5,50,0,c));assert(m.step(0,in,c)==NORMAL);
 m.sample(7.1f,50,1,c);assert(m.step(1,in,c)==ATENCAO);
 m.sample(7,50,2,c);assert(m.step(2,in,c)==NORMAL);
 m.sample(9,50,0,c);assert(m.step(30000,in,c)==ATENCAO);assert(m.step(30001,in,c)==CRITICO);
 in.button=true;assert(m.step(30002,in,c)==RECONHECIDO);assert(m.ventilate(false));
 in.button=false;m.sample(5,50,30003,c);assert(m.step(30003,in,c)==NORMAL);assert(!m.ventilate(false));
 in.door=true;assert(m.step(40000,in,c)==NORMAL);assert(m.step(60000,in,c)==NORMAL);assert(m.step(60001,in,c)==ATENCAO);assert(m.step(100000,in,c)==ATENCAO);assert(m.step(100001,in,c)==CRITICO);
 m.sample(NAN,50,100002,c);m.sample(NAN,50,100003,c);assert(m.step(100003,in,c)==CRITICO);m.sample(NAN,50,100004,c);assert(m.step(100004,in,c)==FALHA_SENSOR);
 in.door=false;m.sample(5,50,100005,c);assert(m.step(100005,in,c)==NORMAL);
 in.light=85;assert(m.step(100006,in,c)==ATENCAO);in.light=0;assert(m.step(100007,in,c)==NORMAL);
 in.vibration=true;assert(m.step(100008,in,c)==ATENCAO);in.vibration=false;assert(m.step(110007,in,c)==ATENCAO);assert(m.step(110008,in,c)==NORMAL);
 m.sample(9,50,120000,c);m.sample(NAN,NAN,140000,c);m.sample(9,50,145000,c);assert(m.step(150001,in,c)==ATENCAO);assert(m.step(175001,in,c)==CRITICO);
 Ring<Packet,32> ring;for(unsigned i=1;i<=70;++i){Packet p;p.seq=i;ring.push(p);}assert(ring.count==32&&ring.dropped==38);
 ring.confirm(1);Packet p;assert(ring.peek(p)&&p.seq==39);
 for(unsigned i=39;i<=70;++i){assert(ring.peek(p)&&p.seq==i);ring.confirm(i);}assert(!ring.peek(p));
 Config bad=c;bad.high=NAN;assert(!validConfig(bad));bad=c;bad.interval=100;assert(!validConfig(bad));
 std::cout<<"FSM, limites, reconhecimento, falhas, extras e 32 leituras em ordem: OK\n";
}
