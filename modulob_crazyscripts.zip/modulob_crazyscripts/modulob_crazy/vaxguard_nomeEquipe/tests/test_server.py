import io
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
import unittest
import zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'servidor'))
from app import create_app,initialize,digest
from werkzeug.security import generate_password_hash
from analytics import analyze,indicators,online_availability


class ServerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.tmp.name)/'test.sqlite3')
        self.app=create_app({'TESTING':True,'SECRET_KEY':'test-only','DATABASE':self.path})
        initialize(self.app)
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO usuarios(nome,senha_hash,perfil) VALUES(?,?,?)',('tester',generate_password_hash('test-password'),'ADMINISTRADOR'))
            db.execute('INSERT OR IGNORE INTO usuarios(nome,senha_hash,perfil) VALUES(?,?,?)',('reader',generate_password_hash('test-password'),'OPERADOR'))
            for name,token in [('VG-CAM01','a'),('VG-CAM02','b')]:
                db.execute('INSERT OR REPLACE INTO dispositivos(id,placa,token_hash,criado_em) VALUES(?,?,?,?)',(name,'ESP32',digest(token),time.time()))
        self.client=self.app.test_client()
        self.headers={'Authorization':'Bearer a'}
        self.now=int(time.time())

    def tearDown(self):
        self.tmp.cleanup()

    def db(self):
        db=sqlite3.connect(self.path)
        db.row_factory=sqlite3.Row
        return db

    def packet(self,seq=1,**kw):
        value={'device_id':'VG-CAM01','placa':'ESP32','seq':seq,'ts':self.now,'temp':5,'umid':50,'porta':0,'estado':'NORMAL','luz_pct':10,'vibracao':0}
        value.update(kw)
        return value

    def post(self,value,headers=None):
        return self.client.post('/api/telemetria',json=value,headers=headers or self.headers)

    def login(self,name='tester'):
        self.client.get('/login')
        with self.client.session_transaction() as session:
            csrf=session['csrf']
        response=self.client.post('/login',data={'nome':name,'senha':'test-password','csrf':csrf})
        self.assertEqual(response.status_code,302)
        with self.client.session_transaction() as session:
            return {'X-CSRF-Token':session['csrf']}

    def test_ingest_dedup_conflict_and_sqlite_tables(self):
        value=self.packet()
        self.assertEqual(self.post(value).status_code,201)
        self.assertEqual(self.post(value).status_code,200)
        self.assertEqual(self.post(self.packet(temp=6)).status_code,409)
        with self.db() as db:
            self.assertEqual(db.execute('SELECT count(*) FROM leituras').fetchone()[0],1)
            names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            self.assertTrue({'dispositivos','leituras','eventos','comandos','usuarios'}<=names)

    def test_token_cannot_impersonate_another_device(self):
        self.assertEqual(self.post(self.packet(device_id='VG-CAM02')).status_code,401)
        self.assertEqual(self.post(self.packet(),{'Authorization':'Bearer wrong'}).status_code,401)

    def test_validation_rejections_logged(self):
        changes=[{'temp':81},{'umid':101},{'seq':True},{'porta':.5},{'vibracao':True},
                 {'temp':float('nan')},{'estado':'DESCONHECIDO'},{'ts':self.now+9999},{'placa':'UNO R4 WiFi'}]
        for kw in changes:
            with self.subTest(kw=kw),self.assertLogs(self.app.logger,level='WARNING'):
                self.assertEqual(self.post(self.packet(**kw)).status_code,400)

    def test_failure_nulls_and_no_clock(self):
        self.assertEqual(self.post(self.packet(ts=None,temp=None,umid=None,estado='FALHA_SENSOR')).status_code,201)
        self.assertEqual(self.post(self.packet(seq=2,temp=None)).status_code,400)

    def test_sessions_csrf_and_operator_permissions(self):
        self.assertEqual(self.client.get('/painel/api/dados').status_code,401)
        csrf=self.login('reader')
        response=self.client.get('/')
        self.assertEqual(response.status_code,200)
        command={'device_id':'VG-CAM01','comando':'REINICIAR','parametros':{}}
        self.assertEqual(self.client.post('/painel/api/comandos',json=command).status_code,400)
        self.assertEqual(self.client.post('/painel/api/comandos',json=command,headers=csrf).status_code,403)

    def test_command_delivery_ack_and_persisted_configuration(self):
        csrf=self.login()
        response=self.client.post('/painel/api/comandos',json={'device_id':'VG-CAM01','comando':'SET_LIMITES','parametros':{'temp_min':3,'temp_max':9}},headers=csrf)
        self.assertEqual(response.status_code,201)
        cid=response.json['id']
        cmds=self.client.get('/api/dispositivos/VG-CAM01/comandos?apos=0',headers=self.headers).json['comandos']
        self.assertEqual(cmds[0]['id'],cid)
        event={'device_id':'VG-CAM01','placa':'ESP32','seq':1,'ts':self.now,'tipo':'COMANDO_EXECUTADO','command_id':cid,'motivo':'Aplicado'}
        self.assertEqual(self.client.post('/api/eventos',json=event,headers=self.headers).status_code,201)
        with self.db() as db:
            self.assertEqual(db.execute('SELECT status FROM comandos WHERE id=?',(cid,)).fetchone()[0],'EXECUTADO')
            self.assertEqual(db.execute("SELECT temp_min FROM dispositivos WHERE id='VG-CAM01'").fetchone()[0],3)
        self.assertEqual(self.client.get('/api/dispositivos/VG-CAM01/comandos?apos='+str(cid),headers=self.headers).json['comandos'],[])

    def test_backfill_does_not_revert_config(self):
        self.assertEqual(self.post(self.packet(seq=20,temp_min=3,temp_max=9,intervalo_ms=6000)).status_code,201)
        self.assertEqual(self.post(self.packet(seq=10,temp_min=2,temp_max=8,intervalo_ms=5000)).status_code,201)
        with self.db() as db:
            row=db.execute("SELECT * FROM dispositivos WHERE id='VG-CAM01'").fetchone()
            self.assertEqual((row['temp_min'],row['intervalo_ms']),(3,6000))

    def test_panel_export_report_and_acknowledgement(self):
        self.post(self.packet())
        event={'device_id':'VG-CAM01','placa':'ESP32','seq':2,'ts':self.now,'tipo':'MUDANCA_ESTADO','anterior':'NORMAL','novo':'ATENCAO','motivo':'Teste'}
        self.client.post('/api/eventos',json=event,headers=self.headers)
        csrf=self.login()
        data=self.client.get('/painel/api/dados').json
        self.assertTrue(data['dispositivos'][0]['online'])
        eid=data['eventos'][0]['id']
        self.assertEqual(self.client.post('/painel/api/eventos/%d/reconhecer'%eid,json={},headers=csrf).status_code,200)
        response=self.client.get('/painel/eventos.csv')
        self.assertEqual(response.status_code,200)
        self.assertIn(b'Teste',response.data)
        response=self.client.get('/painel/relatorio/VG-CAM01')
        self.assertEqual(response.status_code,200)
        with zipfile.ZipFile(io.BytesIO(response.data)) as z:
            self.assertEqual(set(z.namelist()),{'relatorio.md','grafico.png'})
            self.assertTrue(z.read('grafico.png').startswith(b'\x89PNG'))

    def test_new_device_and_validation(self):
        csrf=self.login()
        response=self.client.post('/painel/api/dispositivos',json={'id':'VG-CAM03','placa':'UNO R4 WiFi'},headers=csrf)
        self.assertEqual(response.status_code,201)
        self.assertGreater(len(response.json['token']),30)
        self.assertEqual(self.client.post('/painel/api/comandos',json={'device_id':[], 'comando':'REINICIAR'},headers=csrf).status_code,400)

    def test_online_expires_after_three_intervals(self):
        self.post(self.packet())
        with self.db() as db:
            db.execute("UPDATE dispositivos SET ultimo_recebido=? WHERE id='VG-CAM01'",(time.time()-16,))
        self.login()
        devices=self.client.get('/painel/api/dados').json['dispositivos']
        self.assertFalse(next(d for d in devices if d['id']=='VG-CAM01')['online'])

    def test_ai_forecasts_and_anomaly_without_lookahead(self):
        for i in range(20):
            # Crescimento de .04 C a cada 5 s: previsao de 8 C em ~4 min.
            self.assertEqual(self.post(self.packet(seq=i+1,ts=self.now-100+i*5,temp=5+i*.04)).status_code,201)
        with self.db() as db:
            self.assertTrue(db.execute("SELECT 1 FROM eventos WHERE tipo='RISCO_EXCURSAO'").fetchone())
        self.post(self.packet(seq=21,ts=self.now,temp=15,estado='ATENCAO'))
        with self.db() as db:
            self.assertEqual(db.execute('SELECT anomala FROM leituras WHERE seq=21').fetchone()[0],1)

    def test_telemetry_and_event_share_sequence_namespace(self):
        self.post(self.packet())
        event={'device_id':'VG-CAM01','placa':'ESP32','seq':1,'ts':self.now,'tipo':'BOOT','motivo':'Iniciando'}
        self.assertEqual(self.client.post('/api/eventos',json=event,headers=self.headers).status_code,409)

    def test_kpi_does_not_fill_long_offline_gap(self):
        rows=[{'ts':0,'recebido_em':0,'temp':10,'porta':0},{'ts':100,'recebido_em':100,'temp':5,'porta':1},{'ts':105,'recebido_em':105,'temp':5,'porta':0}]
        k=indicators(rows,0,110,5000,2,8)
        self.assertEqual(k['fora_faixa_s'],15)
        self.assertLess(k['cobertura_dados_pct'],30)
        self.assertEqual(k['aberturas_porta'],0) # lacuna impede comprovar transicao

    def test_availability_uses_contacts_and_does_not_fill_offline_history(self):
        contacts=[{'ts':100,'intervalo_ms':5000},{'ts':110,'intervalo_ms':5000},{'ts':200,'intervalo_ms':5000}]
        self.assertEqual(online_availability(contacts,100,220),33.33)

if __name__=='__main__':
    unittest.main()
