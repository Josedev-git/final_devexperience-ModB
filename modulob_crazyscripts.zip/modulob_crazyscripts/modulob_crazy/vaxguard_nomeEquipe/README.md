# VaxGuard Connect

Monitoramento de câmara fria com DHT11, porta, dois sensores extras, alarmes locais, coleta central, análise temporal e painel de operação.

**Firmware:** C++ com framework Arduino. **Servidor, IA, relatórios e simulador:** Python. **Painel:** HTML, CSS e JavaScript servido pelo Flask. **Banco:** SQLite, criado automaticamente pelo servidor.

## 1. Rodar no Windows

Instale Python **3.10 ou superior** e a Arduino IDE 2.x. Extraia o ZIP antes de executar os arquivos.

1. Entre na pasta `vaxguard_nomeEquipe`.
2. Dê dois cliques em **INICIAR_WINDOWS.bat**.
3. Na primeira execução, aguarde a instalação. O terminal informa as senhas de **admin** e **operador**, além do token do dispositivo físico. Guarde-os; também estão no `.env` local gerado.
4. Abra http://localhost:5000 e entre com essas credenciais.
5. Mantenha o terminal aberto enquanto usar o sistema.
6. Em outra janela, execute **SIMULAR_WINDOWS.bat**. O ponto VG-CAM02 aparece e aquece gradualmente, permitindo testar a previsão e os alertas.

O arquivo `.env` real e a chave de sessão são gerados automaticamente. **Não copie `.env.example` para `.env`**: use `preparar.py`, que gera valores aleatórios de verdade. Não publique `.env`, `secrets.h` nem o banco com os usuários e tokens.

Para executar manualmente pelo CMD, abra um terminal na pasta `vaxguard_nomeEquipe`:

```bat
cd servidor
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe preparar.py
.venv\Scripts\python.exe app.py
```

Em outro CMD, dentro de `servidor`:

```bat
.venv\Scripts\python.exe simulador_dispositivo.py --aquecimento
```

Sem aquecimento:

```bat
.venv\Scripts\python.exe simulador_dispositivo.py
```

Linux/macOS: crie `.venv` com `python3 -m venv .venv`, use `.venv/bin/python` nos comandos equivalentes. `python preparar.py` inicializa o esquema e as contas. Rodar novamente preserva configuração e contas já existentes; mudar a senha no `.env` depois da criação não altera o hash do usuário automaticamente.

Se a porta 5000 estiver ocupada, ajuste `PORT` no `.env`; atualize a URL no navegador, no simulador (`--url`) e em `secrets.h`. O `.bat` abre por padrão a porta 5000. Use `ipconfig` para descobrir o IPv4 do PC e libere essa porta no firewall da rede privada quando integrar o ESP32. O PC e a placa devem alcançar a mesma rede.

## 2. Preparar e carregar a placa

O alvo principal é o **ESP32 DevKit clássico/WROOM**. O mesmo sketch tem HAL para **Arduino UNO R4 WiFi**, cuja compilação também foi verificada.

No gerenciador de placas da Arduino IDE:

| Alvo | Pacote usado na validação | Placa |
|---|---|---|
| ESP32 | esp32 by Espressif Systems **3.0.7** | ESP32 Dev Module |
| UNO R4 WiFi | Arduino UNO R4 Boards **1.5.1** | Arduino UNO R4 WiFi |

Para adicionar o ESP32, use a URL oficial no campo de gerenciadores adicionais: https://espressif.github.io/arduino-esp32/package_esp32_index.json .

Instale no gerenciador de bibliotecas:

| Biblioteca | Versão verificada |
|---|---|
| ArduinoJson | 7.4.2 |
| DHT sensor library, Adafruit | 1.4.6 |
| Adafruit Unified Sensor | 1.1.15 |

WiFi, Preferences e watchdog vêm com o core ESP32. WiFiS3, EEPROM, WDT e Arduino_LED_Matrix vêm com o core Renesas.

1. Abra **firmware/vaxguard/vaxguard.ino**.
2. Copie `secrets.example.h` como **secrets.h**, na mesma pasta.
3. Preencha SSID, senha, `DEVICE_ID`, `API_TOKEN`, `SERVER_URL` e `NTP_IP`.
4. Para a placa inicial, mantenha `DEVICE_ID="VG-CAM01"` e copie **DEVICE_TOKEN** do `.env` do servidor para `API_TOKEN`.
5. `SERVER_URL` deve ser a origem HTTP com **IPv4 literal**, por exemplo `http://192.168.20.10:5000`, sem barra no fim. `localhost` na placa não aponta para o PC.
6. `NTP_IP` deve ser um servidor NTP alcançável, em UDP 123. O PC só serve se um serviço NTP tiver sido configurado nele. Confirme com o avaliador qual IP usar.
7. Selecione placa/porta e clique em **Verificar**, depois **Carregar**.
8. Abra o monitor serial em **115200 baud**. Ele mostra as leituras DHT e as transições de estado.

No UNO R4, cadastre no painel um dispositivo de placa **UNO R4 WiFi** com ID próprio e use o token fornecido. VG-CAM01 e VG-CAM02 são cadastrados inicialmente como ESP32. O servidor rejeita `placa` diferente do cadastro.

## 3. Pinagem e sensores

Todas as decisões específicas de placa estão em **board.h**. `vaxguard.ino` e `core.h` não contêm diretivas condicionais de placa nem acessos a GPIO.

| Função | Componente do kit | ESP32 DevKit | UNO R4 WiFi |
|---|---|---:|---:|
| Temperatura e umidade | DHT11 | GPIO4 | D2 |
| Porta | Magnetic Spring/reed | GPIO27 | D3 |
| Reconhecimento local | Button | GPIO26 | D4 |
| Extra 1: luminosidade | Photoresistor/LDR | GPIO34, ADC1 | A0 |
| Extra 2: vibração | Knock/vibration, KY-002 | GPIO33 | D7 |
| Canal vermelho | RGB LED | GPIO18 | D9 |
| Canal verde | RGB LED | GPIO19 | D10 |
| Canal azul | RGB LED | GPIO21 | D11 |
| Alerta sonoro | **Active Buzzer** | GPIO23 | D5 |
| Ventilação | Relé | GPIO22 | D6 |
| Indicador nativo | RGB PWM / matriz | PWM via ledcWrite | Matriz 12×8: N/A/C/R/F |

O buzzer escolhido é **ativo**, acionado por nível digital. Um buzzer passivo exige adaptar a HAL para gerar a frequência. O RGB deve ter três canais independentes; não usar LED endereçável/automático com esta ligação.

- Reed entre entrada e GND, fechado com porta fechada; usa pull-up. `porta=1` significa aberta.
- Botão entre entrada e GND; pull-up e debounce de 50 ms.
- DHT DATA com pull-up de 4,7–10 kΩ se o módulo não tiver. Alimentação dos sensores conforme a placa: **3,3 V no ESP32** e 5 V no UNO, observando a especificação de cada módulo.
- LDR: VCC → LDR → ponto do ADC → resistor 10 kΩ → GND. Maior luz aumenta a porcentagem. ADC normalizado por 4095 no ESP32 (12 bits) e por 16383 no UNO (14 bits); percentual de código ADC, não lux calibrados.
- GPIO34 é entrada apenas e pertence ao ADC1, compatível com Wi-Fi. Não aplique 5 V em nenhum GPIO do ESP32.
- Vibração ativa em zero, com pull-up e interrupção para reter pulsos curtos. Luz acima de 80% gera ATENCAO; vibração gera ATENCAO por 10 s após o último pulso. Ajuste `lightLimit` em `core.h` se a montagem precisar de calibração.
- Use resistor individual de 220–330 Ω por canal RGB. O padrão é cátodo comum; para ânodo comum, altere `RGB_COMMON_ANODE` em `board.h`.
- Relé padrão ativo em zero; confira `RELAY_ACTIVE_LOW`. Alimente a parte de potência do módulo em 5 V/VIN e use GND comum. O sinal deve ser compatível com 3,3 V no ESP32. Não ligue bobinas/motores diretamente ao GPIO. Demonstre com carga de baixa tensão; não use rede elétrica em protoboard.

## 4. Regras de operação

Faixa inicial: **2–8 °C**. Coleta a cada **5 s**, alterável remotamente entre 2 e 60 s. Para a demonstração em temperatura ambiente, altere os limites no painel conforme a temperatura da bancada e restaure a configuração depois.

| Estado | Condição | Ação |
|---|---|---|
| NORMAL | Temperatura válida dentro da faixa, sem alerta adicional | Verde; ventilação em repouso |
| ATENCAO | A menos de 1 °C de um limite, fora da faixa ainda em tolerância, porta >20 s, luz alta ou vibração | Amarelo; bipe de 150 ms a cada 10 s |
| CRITICO | Temperatura fora da faixa >30 s ou porta >60 s | Vermelho; buzzer contínuo; relé ligado |
| RECONHECIDO | Nova pressão de botão enquanto CRITICO | Buzzer silenciado, vermelho piscando; ventilação mantida |
| FALHA_SENSOR | 3 leituras inválidas consecutivas | Amarelo/vermelho alternando; evento SENSOR_FALHA |

Regras para situações que o PDF não detalha:

- Porta aberta por até 20 s tem tolerância: sem outro alerta, mantém NORMAL, mas `porta=1` já é enviada.
- Inicialização sem leitura válida e 1–2 falhas do DHT usam ATENCAO preventiva. NaN, infinito e valores fora das faixas aceitas contam como inválidos.
- Uma leitura inválida interrompe a contagem de excursão comprovada por temperatura. A próxima válida fora da faixa reinicia a contagem. A temporização da porta continua independente.
- FALHA_SENSOR tem prioridade visual e liga a ventilação por decisão conservadora. Uma amostra válida recupera o sensor e reavalia a FSM.
- RECONHECIDO fica retido até temperatura válida na faixa, porta fechada e extras normalizados. O botão precisa de uma nova pressão em CRITICO; segurar o botão antes do alarme não o reconhece automaticamente.
- `VENTILACAO_OFF` limpa o acionamento manual, mas preserva a ventilação exigida pelo alarme local. ON manual vale até OFF ou reboot.
- Os tempos usam `>`: exatamente 20, 30 ou 60 s ainda não vencem o prazo. Os limites da faixa são inclusivos; a margem usa distância estritamente menor que 1 °C.
- Cada transição gera evento com anterior, novo e motivo. A ocorrência de SENSOR_FALHA é emitida ao entrar no estado, sem repetir a cada coleta.

## 5. Temporização, rede e persistência

`loop()` executa leitura/controle local e cede execução com `yield()`. Não usa `delay()`, `sleep()` nem laço de espera de reconexão. A coleta usa `millis()` com diferença sem sinal; uptime acumulado de 64 bits tolera o wrap do contador. DHT é amostrado separadamente do processamento de botão/porta/saídas.

**ESP32:** a HAL cria uma tarefa FreeRTOS para rede. Wi-Fi, TCP e NTP não aguardam respostas no loop local. As filas usam seções críticas apenas para cópias curtas. O watchdog do loop local de 8 s reinicia a placa se o controle travar.

**UNO R4:** a HAL usa passos cooperativos, `WiFi.setTimeout(100)` e `setConnectionTimeout(100)`, sem espera ativa da aplicação. O próprio driver WiFiS3 tem chamadas síncronas ao coprocessador; sua latência precisa ser medida em bancada. A compilação na segunda placa está verificada, mas ela não oferece a mesma separação em tarefa do ESP32. O watchdog WDT é habilitado.

A transação física DHT11 e as gravações de EEPROM/NVS têm latência finita. Compilação e testes lógicos não equivalem a garantia de tempo real rígido.

Wi-Fi: janela de associação até 8 s e esperas progressivas de 1, 2, 4, 8, 16 e 30 s. HTTP usa uma máquina de passos de envio/recepção, até 256 bytes por chamada, resposta até 2 KiB e timeout de 4 s. Erros preservam o registro para nova tentativa. IPv4 literal evita DNS síncrono. O NTP verifica origem, modo, stratum e cookie de resposta; tenta a cada 30 s até sincronizar e depois a cada hora.

As configurações e o cursor de comandos ficam em **Preferences no ESP32** e **EEPROM no UNO**. Duas cópias com geração e checksum preservam a última gravação válida. O contador `seq` é reservado em blocos persistentes de 512 números; após reboot há lacunas, sem reutilização enquanto a memória não for apagada. Atualizações que mudem o layout do armazenamento exigem migração; apagar a flash requer recadastrar a identidade para evitar conflitos de sequência.

O buffer circular tem **32 leituras**, mais **16 eventos** em outra fila. O reenvio compara as cabeças por sequência, preservando a ordem global dos registros retidos, inclusive se novas coletas chegarem durante o envio. Só confirma/remove após HTTP 2xx completo. Se houver overflow, descarta o mais antigo e conta perdas. A confirmação de um item já descartado não remove outro item.

O buffer está em **RAM**: reinício ou falta de energia perde o histórico pendente; o PDF exige persistência da configuração, não persistência de todas as leituras. Há cerca de 160 s de leituras no padrão de 5 s, suficiente para o mínimo solicitado. O comando REINICIAR aguarda 5 s para tentar transmitir o ACK antes do reset; o cursor persistido evita repetição.

## 6. Protocolo integrado com a API

Credencial por dispositivo: `Authorization: Bearer TOKEN`. O banco guarda hash SHA-256 do token. Os caminhos são os mesmos no firmware, no simulador e no Flask.

| Método e caminho | Função |
|---|---|
| POST `/api/telemetria` | Validar e persistir amostra |
| POST `/api/eventos` | Persistir transição, BOOT ou resultado de comando |
| GET `/api/dispositivos/<id>/comandos?apos=<id>` | Obter próximo comando pendente em ordem |
| GET `/saude` | Verificar funcionamento da API |
| GET `/painel/api/dados` | Dados do painel, exige sessão |
| POST `/painel/api/comandos` | Enfileirar comando, apenas administrador |
| POST `/painel/api/dispositivos` | Cadastrar dispositivo e gerar token, apenas administrador |
| POST `/painel/api/eventos/<id>/reconhecer` | Registrar ciência, operador ou administrador |
| GET `/painel/eventos.csv` | Eventos filtrados por período |
| GET `/painel/relatorio/<id>` | ZIP com relatório Markdown e gráfico PNG |

Exemplo de amostra:

```json
{"device_id":"VG-CAM01","placa":"ESP32","seq":42,"ts":1792573200,"temp":5,"umid":50,"porta":0,"estado":"NORMAL","luz_pct":15,"vibracao":0,"temp_min":2,"temp_max":8,"intervalo_ms":5000}
```

`ts` é Unix UTC em segundos. Antes do NTP, envia `null`; o servidor preserva essa ausência e usa horário de recebimento como aproximação nos gráficos. O payload não é reescrito no retry, garantindo idempotência mesmo se o primeiro POST foi salvo e a resposta se perdeu. DHT inválido envia `temp=null` e `umid=null`, sem reciclar valores antigos.

O firmware informa as configurações efetivamente aplicadas em cada amostra. Elas atualizam o cadastro apenas se a sequência for mais nova, evitando que reenvio de histórico reverta limites recentes. O servidor mantém os limites por amostra para relatórios e KPIs; clientes antigos sem esses campos usam os limites atuais como aproximação.

O servidor valida números finitos, inteiros, estados, temperatura −40 a 80, umidade 0 a 100, placa e identidade. Rejeições geram log no terminal, sem gravar credenciais. Uma tabela `registros` impõe unicidade de `(device_id,seq)` entre telemetria e eventos. Reenvio idêntico retorna 200; reutilização da sequência com conteúdo diferente retorna 409. Não apague a memória da placa sem tratar essa identidade no servidor.

Comandos aceitos:

```json
{"device_id":"VG-CAM01","comando":"SET_LIMITES","parametros":{"temp_min":2,"temp_max":8}}
{"device_id":"VG-CAM01","comando":"SET_INTERVALO","parametros":{"intervalo_ms":5000}}
{"device_id":"VG-CAM01","comando":"VENTILACAO_ON","parametros":{}}
{"device_id":"VG-CAM01","comando":"VENTILACAO_OFF","parametros":{}}
{"device_id":"VG-CAM01","comando":"REINICIAR","parametros":{}}
```

A largura da faixa deve ser >2 °C para existir uma região fora das margens de atenção. Comandos usam ID inteiro crescente e confirmação por evento COMANDO_EXECUTADO/COMANDO_REJEITADO. O cursor persistido também recupera a confirmação após reboot; `CONFIRMADO_CURSOR` indica aceitação do cursor sem o evento de resultado. Gravação de configuração e cursor são operações separadas: queda de energia entre elas pode provocar reaplicação idempotente.

Respostas do Flask usam Content-Length, JSON pequeno e sem chunked/compressão. Não coloque proxy que altere essas condições sem adaptar o cliente. HTTP é o transporte permitido para a rede do exercício; não cifra tokens. Uma implantação real exige HTTPS com validação de certificado, sessão Secure e servidor WSGI apropriado. O `app.run` incluído é para demonstração local.

## 7. Painel, IA e indicadores

- Login com senha em hash scrypt, sessão assinada com chave aleatória, cookie HttpOnly/SameSite, proteção CSRF e limitação simples de tentativas de login.
- **OPERADOR:** consulta dados e registra ciência dos eventos. **ADMINISTRADOR:** também cadastra dispositivos, muda limites/intervalos e envia comandos.
- Reconhecer no painel registra quem tomou ciência; o silenciamento físico continua sendo feito pelo botão local, conforme a FSM.
- Atualização a cada 5 s, gráfico de temperatura/umidade/faixa, estado, placa e ONLINE/OFFLINE. Offline significa ausência de comunicação por mais de três intervalos. A consulta de comandos também comprova que a placa está alcançando a API.
- Filtro de período para eventos, gráficos e relatórios; exportação CSV neutraliza células que poderiam virar fórmulas. O painel exibe até 720 pontos e 200 eventos; relatórios/CSV usam o período completo, limitado a 31 dias.
- **Anomalias:** z-score móvel ajustado usando até 60 amostras anteriores válidas, janela de 10 min, mínimo de 6, desvio mínimo de 0,25 °C e diferença >2 °C em relação à amostra anterior. Essa combinação sinaliza saltos incompatíveis sem tratar todo aquecimento gradual como outlier.
- **Previsão:** regressão linear sobre os últimos 2 min de dados não anômalos, mínimo 6 pontos e 30 s de observação. Se prevê ultrapassar um limite em menos de 5 min, ainda sem CRITICO, gera RISCO DE EXCURSAO. Alertas iguais têm espaçamento temporal para não inundar a lista.
- **KPIs:** tempo estimado fora da faixa, aberturas observadas, média de aberturas completas, disponibilidade online, cobertura de telemetria e temperatura mínima/média/máxima. Lacunas acima de três intervalos não são preenchidas. Aberturas incompletas no início/fim do período não entram na média.
- Disponibilidade histórica usa contatos HTTP efetivamente recebidos, em resolução de um segundo, e a união das janelas ONLINE de três intervalos. Cobertura de dados é um indicador separado: reenvio recupera amostras sem apagar a indisponibilidade passada. O ONLINE atual é calculado pela última comunicação recente.
- O relatório baixa como ZIP com **relatorio.md** e **grafico.png**. Extraia os dois juntos para visualizar o gráfico pelo Markdown no VS Code. Inclui identificação, período, limites, indicadores, gráfico, excursões e método de estimativa.

O kit e a análise estatística são recursos didáticos; faltam calibração e validação metrológica para aplicação real na cadeia de frio.

## 8. Roteiro de teste em bancada

1. Rode servidor e simulador; confira VG-CAM02 online e o alerta preventivo durante aquecimento.
2. Carregue a placa com credenciais corretas. Confira VG-CAM01 no painel e leituras no monitor serial.
3. Ajuste limites próximos da temperatura ambiente para demonstrar NORMAL sem resfriar o kit.
4. Abra o reed por >20 s e depois >60 s: verifique amarelo/bipes, depois vermelho/buzzer/relé.
5. Pressione o botão em CRITICO: buzzer silencia e vermelho pisca; feche a porta e normalize as demais condições.
6. Desconecte DATA do DHT: após três coletas inválidas, confira FALHA_SENSOR e evento no painel.
7. Ilumine o LDR e acione vibração separadamente; ambos devem influenciar ATENCAO.
8. Derrube o Wi-Fi por cerca de 60 s mantendo a placa ligada. Alarmes devem continuar; ao reconectar, confira sequência e reenvio das leituras/eventos.
9. Altere limites e intervalo pelo painel; desligue/ligue a placa e confira que persistiram.
10. Teste ON/OFF e REINICIAR, observando o resultado dos comandos. OFF não cancela proteção local.
11. Para verificar watchdog, faça uma alteração temporária que interrompa o progresso local; ele deve reiniciar em aproximadamente 8 s. Remova a alteração após o teste.

Não houve montagem física nesta execução. NTP, níveis elétricos, polaridade do módulo, latências WiFiS3 e watchdog precisam ser comprovados na placa.

## 9. Testes automatizados e compilação

Dentro de `vaxguard_nomeEquipe`, com as dependências do servidor instaladas:

```bat
servidor\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Em Linux/macOS: `python3 -m unittest discover -s tests -v`.

Teste da FSM no PC com g++:

```bash
g++ -std=c++11 -Wall -Wextra -pedantic tests/test_fsm.cpp -o test_fsm
./test_fsm
```

Compilação com Arduino CLI, após instalar os cores e bibliotecas indicados e criar `secrets.h`:

```bash
arduino-cli compile --fqbn esp32:esp32:esp32 firmware/vaxguard
arduino-cli compile --fqbn arduino:renesas_uno:unor4wifi firmware/vaxguard
```

Se compilar simultaneamente para placas diferentes, use caminhos `--build-path` distintos. O código contém compatibilidade de API LEDC para cores ESP32 2.x/3.x; as versões efetivamente compiladas nesta entrega constam em `VALIDACAO.md`.

## 10. Entrega formal

A pasta principal segue `modulob_nomeEquipe/vaxguard_nomeEquipe`. Substitua nomeEquipe antes de publicar. Crie o repositório GitHub com o nome pedido, conceda acesso a **Cardoso30S**, **fiorezewesley** e **Greggori**, e faça commits reais distribuídos ao longo do trabalho. O pacote não cria um repositório remoto nem fabrica oito commits retroativos.

A perícia da Parte 2 precisa do `.pcap` original e de capturas reais do Wireshark; veja `../pericia/README.md`.

Referências de API: documentação oficial Arduino UNO R4, Arduino-ESP32 LEDC/Preferences e Flask 3.1. Requisitos: PDF SENAI Dev Experience Módulo B 2026 fornecido pelo usuário.
